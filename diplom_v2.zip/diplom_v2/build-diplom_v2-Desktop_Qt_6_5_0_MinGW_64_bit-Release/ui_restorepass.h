/********************************************************************************
** Form generated from reading UI file 'restorepass.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESTOREPASS_H
#define UI_RESTOREPASS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_RestorePass
{
public:
    QLineEdit *pass;
    QLabel *label_29;
    QLabel *label_27;
    QLabel *send_code_err;
    QLabel *label_37;
    QPushButton *send_code;
    QLabel *conf_pass_err;
    QLabel *result_reg;
    QLabel *label;
    QLabel *label_30;
    QPushButton *cancel_btn;
    QLineEdit *code;
    QLineEdit *conf_pass;
    QLabel *code_err;
    QLineEdit *email;
    QLabel *label_31;
    QLabel *timer_text;
    QPushButton *register_btn;
    QLabel *email_err;
    QLabel *pass_err;
    QLabel *timer_err;

    void setupUi(QDialog *RestorePass)
    {
        if (RestorePass->objectName().isEmpty())
            RestorePass->setObjectName("RestorePass");
        RestorePass->resize(575, 497);
        pass = new QLineEdit(RestorePass);
        pass->setObjectName("pass");
        pass->setGeometry(QRect(170, 100, 200, 31));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pass->sizePolicy().hasHeightForWidth());
        pass->setSizePolicy(sizePolicy);
        pass->setMinimumSize(QSize(200, 31));
        pass->setEchoMode(QLineEdit::Password);
        label_29 = new QLabel(RestorePass);
        label_29->setObjectName("label_29");
        label_29->setGeometry(QRect(40, 100, 111, 31));
        label_27 = new QLabel(RestorePass);
        label_27->setObjectName("label_27");
        label_27->setGeometry(QRect(40, 280, 121, 31));
        send_code_err = new QLabel(RestorePass);
        send_code_err->setObjectName("send_code_err");
        send_code_err->setGeometry(QRect(410, 340, 131, 31));
        send_code_err->setStyleSheet(QString::fromUtf8(""));
        label_37 = new QLabel(RestorePass);
        label_37->setObjectName("label_37");
        label_37->setGeometry(QRect(190, 340, 221, 41));
        QFont font;
        font.setItalic(true);
        label_37->setFont(font);
        send_code = new QPushButton(RestorePass);
        send_code->setObjectName("send_code");
        send_code->setGeometry(QRect(40, 350, 131, 31));
        conf_pass_err = new QLabel(RestorePass);
        conf_pass_err->setObjectName("conf_pass_err");
        conf_pass_err->setGeometry(QRect(410, 160, 131, 31));
        conf_pass_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        result_reg = new QLabel(RestorePass);
        result_reg->setObjectName("result_reg");
        result_reg->setGeometry(QRect(330, 430, 161, 31));
        result_reg->setStyleSheet(QString::fromUtf8("color: green;"));
        label = new QLabel(RestorePass);
        label->setObjectName("label");
        label->setGeometry(QRect(40, 30, 251, 41));
        QFont font1;
        font1.setPointSize(18);
        label->setFont(font1);
        label_30 = new QLabel(RestorePass);
        label_30->setObjectName("label_30");
        label_30->setGeometry(QRect(40, 150, 121, 41));
        cancel_btn = new QPushButton(RestorePass);
        cancel_btn->setObjectName("cancel_btn");
        cancel_btn->setGeometry(QRect(210, 430, 91, 31));
        code = new QLineEdit(RestorePass);
        code->setObjectName("code");
        code->setGeometry(QRect(170, 280, 200, 31));
        sizePolicy.setHeightForWidth(code->sizePolicy().hasHeightForWidth());
        code->setSizePolicy(sizePolicy);
        code->setMinimumSize(QSize(200, 31));
        conf_pass = new QLineEdit(RestorePass);
        conf_pass->setObjectName("conf_pass");
        conf_pass->setGeometry(QRect(170, 160, 200, 31));
        sizePolicy.setHeightForWidth(conf_pass->sizePolicy().hasHeightForWidth());
        conf_pass->setSizePolicy(sizePolicy);
        conf_pass->setMinimumSize(QSize(200, 31));
        conf_pass->setEchoMode(QLineEdit::Password);
        code_err = new QLabel(RestorePass);
        code_err->setObjectName("code_err");
        code_err->setGeometry(QRect(410, 280, 131, 31));
        code_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        email = new QLineEdit(RestorePass);
        email->setObjectName("email");
        email->setGeometry(QRect(170, 220, 200, 31));
        sizePolicy.setHeightForWidth(email->sizePolicy().hasHeightForWidth());
        email->setSizePolicy(sizePolicy);
        email->setMinimumSize(QSize(200, 31));
        label_31 = new QLabel(RestorePass);
        label_31->setObjectName("label_31");
        label_31->setGeometry(QRect(40, 210, 86, 41));
        timer_text = new QLabel(RestorePass);
        timer_text->setObjectName("timer_text");
        timer_text->setGeometry(QRect(190, 390, 191, 31));
        timer_text->setStyleSheet(QString::fromUtf8(""));
        register_btn = new QPushButton(RestorePass);
        register_btn->setObjectName("register_btn");
        register_btn->setEnabled(true);
        register_btn->setGeometry(QRect(40, 430, 151, 31));
        email_err = new QLabel(RestorePass);
        email_err->setObjectName("email_err");
        email_err->setGeometry(QRect(410, 220, 131, 31));
        email_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        pass_err = new QLabel(RestorePass);
        pass_err->setObjectName("pass_err");
        pass_err->setGeometry(QRect(410, 100, 131, 31));
        pass_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        timer_err = new QLabel(RestorePass);
        timer_err->setObjectName("timer_err");
        timer_err->setGeometry(QRect(410, 390, 111, 31));
        timer_err->setStyleSheet(QString::fromUtf8(""));

        retranslateUi(RestorePass);

        QMetaObject::connectSlotsByName(RestorePass);
    } // setupUi

    void retranslateUi(QDialog *RestorePass)
    {
        RestorePass->setWindowTitle(QCoreApplication::translate("RestorePass", "\320\222\321\226\320\264\320\275\320\276\320\262\320\273\320\265\320\275\320\275\321\217 \320\277\320\260\321\200\320\276\320\273\321\216", nullptr));
        label_29->setText(QCoreApplication::translate("RestorePass", "\320\235\320\276\320\262\320\270\320\271 \320\277\320\260\321\200\320\276\320\273\321\214 :", nullptr));
        label_27->setText(QCoreApplication::translate("RestorePass", "\320\232\320\276\320\264 \321\200\320\265\321\224\321\201\321\202\321\200\320\260\321\206\321\226\321\227 :", nullptr));
        send_code_err->setText(QString());
        label_37->setText(QCoreApplication::translate("RestorePass", "(\320\264\320\273\321\217 \320\262\321\226\320\264\320\277\321\200\320\260\320\262\320\272\320\270 \320\272\320\276\320\264\321\203 \320\262\320\262\320\265\320\264\321\226\321\202\321\214\n"
"\320\265\320\273\320\265\320\272\321\202\321\200\320\276\320\275\320\275\321\203 \320\260\320\264\321\200\320\265\321\201\321\203)", nullptr));
        send_code->setText(QCoreApplication::translate("RestorePass", "\320\222\321\226\320\264\320\277\321\200\320\260\320\262\320\270\321\202\320\270 \320\272\320\276\320\264", nullptr));
        conf_pass_err->setText(QString());
        result_reg->setText(QString());
        label->setText(QCoreApplication::translate("RestorePass", "\320\222\321\226\320\264\320\275\320\276\320\262\320\270\321\202\320\270 \320\277\320\260\321\200\320\276\320\273\321\214", nullptr));
        label_30->setText(QCoreApplication::translate("RestorePass", "\320\237\321\226\320\264\321\202\320\262\320\265\321\200\320\264\320\266\320\265\320\275\320\275\321\217 \n"
"\320\275\320\262\320\276\320\263\320\276 \320\277\320\260\321\200\320\276\320\273\321\216 :", nullptr));
        cancel_btn->setText(QCoreApplication::translate("RestorePass", "\320\235\320\260\320\267\320\260\320\264", nullptr));
        code_err->setText(QString());
        label_31->setText(QCoreApplication::translate("RestorePass", "\320\225\320\273\320\265\320\272\321\202\321\200\320\276\320\275\320\275\320\260\n"
"\320\277\320\276\321\210\321\202\320\260 :", nullptr));
        timer_text->setText(QString());
        register_btn->setText(QCoreApplication::translate("RestorePass", "\320\222\321\226\320\264\320\275\320\276\320\262\320\270\321\202\320\270 \320\277\320\260\321\200\320\276\320\273\321\214", nullptr));
        email_err->setText(QString());
        pass_err->setText(QString());
        timer_err->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class RestorePass: public Ui_RestorePass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESTOREPASS_H
