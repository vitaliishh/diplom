/********************************************************************************
** Form generated from reading UI file 'produtctna.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRODUTCTNA_H
#define UI_PRODUTCTNA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ProdutctNa
{
public:
    QLabel *label_3;
    QPushButton *pushButton;
    QLabel *final_err;
    QTableWidget *product_na_table;
    QPushButton *pushButton_2;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *from_edit;
    QLabel *label_2;
    QLineEdit *to_edit;
    QLabel *label_4;
    QDateEdit *dateEdit;
    QLabel *err1;
    QLabel *err2;
    QLabel *send_err;
    QPushButton *pushButton_3;

    void setupUi(QDialog *ProdutctNa)
    {
        if (ProdutctNa->objectName().isEmpty())
            ProdutctNa->setObjectName("ProdutctNa");
        ProdutctNa->resize(644, 641);
        label_3 = new QLabel(ProdutctNa);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(0, 20, 641, 51));
        QFont font;
        font.setPointSize(14);
        font.setBold(false);
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignCenter);
        label_3->setMargin(10);
        pushButton = new QPushButton(ProdutctNa);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(30, 580, 93, 29));
        final_err = new QLabel(ProdutctNa);
        final_err->setObjectName("final_err");
        final_err->setGeometry(QRect(370, 379, 241, 20));
        final_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        product_na_table = new QTableWidget(ProdutctNa);
        product_na_table->setObjectName("product_na_table");
        product_na_table->setGeometry(QRect(30, 80, 581, 271));
        QFont font1;
        font1.setPointSize(10);
        product_na_table->setFont(font1);
        pushButton_2 = new QPushButton(ProdutctNa);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(30, 374, 151, 29));
        layoutWidget = new QWidget(ProdutctNa);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(30, 430, 371, 131));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName("label");

        gridLayout->addWidget(label, 0, 0, 1, 1);

        from_edit = new QLineEdit(layoutWidget);
        from_edit->setObjectName("from_edit");
        from_edit->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(from_edit, 0, 1, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName("label_2");

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        to_edit = new QLineEdit(layoutWidget);
        to_edit->setObjectName("to_edit");
        to_edit->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(to_edit, 1, 1, 1, 1);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName("label_4");

        gridLayout->addWidget(label_4, 2, 0, 1, 1);

        dateEdit = new QDateEdit(layoutWidget);
        dateEdit->setObjectName("dateEdit");
        dateEdit->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(dateEdit, 2, 1, 1, 1);

        err1 = new QLabel(ProdutctNa);
        err1->setObjectName("err1");
        err1->setGeometry(QRect(420, 443, 191, 20));
        err1->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        err2 = new QLabel(ProdutctNa);
        err2->setObjectName("err2");
        err2->setGeometry(QRect(420, 484, 191, 20));
        err2->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        send_err = new QLabel(ProdutctNa);
        send_err->setObjectName("send_err");
        send_err->setGeometry(QRect(140, 583, 381, 20));
        send_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        pushButton_3 = new QPushButton(ProdutctNa);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(200, 374, 151, 29));

        retranslateUi(ProdutctNa);

        QMetaObject::connectSlotsByName(ProdutctNa);
    } // setupUi

    void retranslateUi(QDialog *ProdutctNa)
    {
        ProdutctNa->setWindowTitle(QCoreApplication::translate("ProdutctNa", "\320\235\320\260\320\272\320\273\320\260\320\264\320\275\320\260", nullptr));
        label_3->setText(QCoreApplication::translate("ProdutctNa", "\320\235\320\260\320\272\320\273\320\260\320\264\320\275\320\260 \320\275\320\260 \320\262\320\270\320\264\320\260\321\207\321\203 \321\202\320\276\320\262\320\260\321\200\321\203", nullptr));
        pushButton->setText(QCoreApplication::translate("ProdutctNa", "\320\227\320\260\320\277\321\200\320\276\321\201\320\270\321\202\320\270", nullptr));
        final_err->setText(QString());
        pushButton_2->setText(QCoreApplication::translate("ProdutctNa", "\320\224\320\276\320\264\320\260\321\202\320\270 \320\277\320\276\320\267\320\270\321\206\321\226\321\216", nullptr));
        label->setText(QCoreApplication::translate("ProdutctNa", "\320\227\320\264\320\260\320\262", nullptr));
        label_2->setText(QCoreApplication::translate("ProdutctNa", "\320\237\321\200\320\270\320\271\320\275\321\217\320\262   ", nullptr));
        label_4->setText(QCoreApplication::translate("ProdutctNa", "\320\224\320\260\321\202\320\260", nullptr));
        dateEdit->setDisplayFormat(QCoreApplication::translate("ProdutctNa", "yyyy-MM-dd", nullptr));
        err1->setText(QString());
        err2->setText(QString());
        send_err->setText(QString());
        pushButton_3->setText(QCoreApplication::translate("ProdutctNa", "\320\222\320\270\320\264\320\260\320\273\320\270\321\202\320\270 \320\277\320\276\320\267\320\270\321\206\321\226\321\216", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProdutctNa: public Ui_ProdutctNa {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRODUTCTNA_H
