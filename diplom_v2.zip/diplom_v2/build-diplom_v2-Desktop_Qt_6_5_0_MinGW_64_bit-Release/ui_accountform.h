/********************************************************************************
** Form generated from reading UI file 'accountform.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCOUNTFORM_H
#define UI_ACCOUNTFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AccountForm
{
public:
    QLabel *label_4;
    QPushButton *pushButton;
    QLabel *err2;
    QLabel *err3;
    QLabel *final_err;
    QPushButton *pushButton_2;
    QLabel *err4;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLabel *label;
    QComboBox *comboBox;
    QLabel *label_5;
    QLineEdit *lineEdit_3;
    QLabel *label_11;
    QLineEdit *lineEdit_8;
    QLabel *label_12;
    QLineEdit *lineEdit_9;
    QLabel *label_6;
    QLineEdit *lineEdit_4;
    QLabel *label_7;
    QLineEdit *lineEdit_5;
    QLabel *label_8;
    QLineEdit *lineEdit_6;
    QLabel *label_9;
    QDateEdit *dateEdit;
    QLabel *label_10;
    QLineEdit *lineEdit_7;

    void setupUi(QDialog *AccountForm)
    {
        if (AccountForm->objectName().isEmpty())
            AccountForm->setObjectName("AccountForm");
        AccountForm->resize(671, 639);
        label_4 = new QLabel(AccountForm);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(100, 10, 461, 51));
        QFont font;
        font.setPointSize(14);
        font.setBold(false);
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignCenter);
        label_4->setMargin(10);
        pushButton = new QPushButton(AccountForm);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(131, 580, 91, 31));
        err2 = new QLabel(AccountForm);
        err2->setObjectName("err2");
        err2->setGeometry(QRect(540, 160, 121, 20));
        err2->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        err3 = new QLabel(AccountForm);
        err3->setObjectName("err3");
        err3->setGeometry(QRect(540, 410, 121, 20));
        err3->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        final_err = new QLabel(AccountForm);
        final_err->setObjectName("final_err");
        final_err->setGeometry(QRect(251, 588, 151, 20));
        final_err->setStyleSheet(QString::fromUtf8("color: green;"));
        pushButton_2 = new QPushButton(AccountForm);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(31, 580, 91, 31));
        err4 = new QLabel(AccountForm);
        err4->setObjectName("err4");
        err4->setGeometry(QRect(540, 260, 121, 20));
        err4->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        layoutWidget = new QWidget(AccountForm);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(31, 90, 481, 471));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName("label");

        gridLayout->addWidget(label, 0, 0, 1, 1);

        comboBox = new QComboBox(layoutWidget);
        comboBox->setObjectName("comboBox");
        comboBox->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(comboBox, 0, 1, 1, 1);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName("label_5");

        gridLayout->addWidget(label_5, 1, 0, 1, 1);

        lineEdit_3 = new QLineEdit(layoutWidget);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(lineEdit_3, 1, 1, 1, 1);

        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName("label_11");

        gridLayout->addWidget(label_11, 2, 0, 1, 1);

        lineEdit_8 = new QLineEdit(layoutWidget);
        lineEdit_8->setObjectName("lineEdit_8");
        lineEdit_8->setMinimumSize(QSize(0, 30));
        lineEdit_8->setEchoMode(QLineEdit::Normal);

        gridLayout->addWidget(lineEdit_8, 2, 1, 1, 1);

        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName("label_12");

        gridLayout->addWidget(label_12, 3, 0, 1, 1);

        lineEdit_9 = new QLineEdit(layoutWidget);
        lineEdit_9->setObjectName("lineEdit_9");
        lineEdit_9->setMinimumSize(QSize(0, 30));
        lineEdit_9->setEchoMode(QLineEdit::Normal);

        gridLayout->addWidget(lineEdit_9, 3, 1, 1, 1);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName("label_6");

        gridLayout->addWidget(label_6, 4, 0, 1, 1);

        lineEdit_4 = new QLineEdit(layoutWidget);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(lineEdit_4, 4, 1, 1, 1);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName("label_7");

        gridLayout->addWidget(label_7, 5, 0, 1, 1);

        lineEdit_5 = new QLineEdit(layoutWidget);
        lineEdit_5->setObjectName("lineEdit_5");
        lineEdit_5->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(lineEdit_5, 5, 1, 1, 1);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName("label_8");

        gridLayout->addWidget(label_8, 6, 0, 1, 1);

        lineEdit_6 = new QLineEdit(layoutWidget);
        lineEdit_6->setObjectName("lineEdit_6");
        lineEdit_6->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(lineEdit_6, 6, 1, 1, 1);

        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName("label_9");

        gridLayout->addWidget(label_9, 7, 0, 1, 1);

        dateEdit = new QDateEdit(layoutWidget);
        dateEdit->setObjectName("dateEdit");
        dateEdit->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(dateEdit, 7, 1, 1, 1);

        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName("label_10");

        gridLayout->addWidget(label_10, 8, 0, 1, 1);

        lineEdit_7 = new QLineEdit(layoutWidget);
        lineEdit_7->setObjectName("lineEdit_7");
        lineEdit_7->setMinimumSize(QSize(0, 30));
        lineEdit_7->setEchoMode(QLineEdit::Normal);

        gridLayout->addWidget(lineEdit_7, 8, 1, 1, 1);


        retranslateUi(AccountForm);

        QMetaObject::connectSlotsByName(AccountForm);
    } // setupUi

    void retranslateUi(QDialog *AccountForm)
    {
        AccountForm->setWindowTitle(QCoreApplication::translate("AccountForm", "\320\244\320\276\321\200\320\274\320\260 \321\201\321\202\320\262\320\276\321\200\320\265\320\275\320\275\321\217 \321\200\320\260\321\205\321\203\320\275\320\272\321\203", nullptr));
        label_4->setText(QCoreApplication::translate("AccountForm", "\320\241\321\202\320\262\320\276\321\200\320\270\321\202\320\270 \321\200\320\260\321\205\321\203\320\275\320\276\320\272", nullptr));
        pushButton->setText(QCoreApplication::translate("AccountForm", "\320\224\320\276\320\264\320\260\321\202\320\270", nullptr));
        err2->setText(QString());
        err3->setText(QString());
        final_err->setText(QString());
        pushButton_2->setText(QCoreApplication::translate("AccountForm", "\320\235\320\260\320\267\320\260\320\264", nullptr));
        err4->setText(QString());
        label->setText(QCoreApplication::translate("AccountForm", "\320\237\320\276\320\272\321\203\320\277\320\265\321\206\321\214", nullptr));
        label_5->setText(QCoreApplication::translate("AccountForm", "\320\237\320\276\321\201\321\202\320\260\321\207\320\260\320\273\321\214\320\275\320\270\320\272", nullptr));
        label_11->setText(QCoreApplication::translate("AccountForm", "\320\220\320\264\321\200\320\265\321\201\320\260 \320\277\320\276\321\201\321\202\320\260\321\207\320\260\320\273\321\214\320\275\320\270\320\272\320\260", nullptr));
        label_12->setText(QCoreApplication::translate("AccountForm", "\320\222\320\270\320\277\320\270\321\201\320\260\320\262(\320\273\320\260)", nullptr));
        label_6->setText(QCoreApplication::translate("AccountForm", "\320\242\320\265\320\273\320\265\321\204\320\276\320\275 \320\277\320\276\321\201\321\202\320\260\321\207\320\260\320\273\321\214\320\275\320\270\320\272\320\260", nullptr));
        label_7->setText(QCoreApplication::translate("AccountForm", "\320\255\320\224\320\240\320\237\320\236\320\243", nullptr));
        label_8->setText(QCoreApplication::translate("AccountForm", "\320\240\320\260\321\205\321\203\320\275\320\276\320\272 \320\276\321\202\321\200\320\270\320\274\321\203\320\262\320\260\321\207\320\260", nullptr));
        label_9->setText(QCoreApplication::translate("AccountForm", "\320\224\320\260\321\202\320\260 \320\276\321\202\321\200\320\270\320\274\320\260\320\275\320\275\321\217", nullptr));
        label_10->setText(QCoreApplication::translate("AccountForm", "\320\235\320\260\320\264\320\260\320\262\320\260\321\207 \320\277\320\273\320\260\321\202\321\226\320\266\320\275\320\270\321\205 \n"
"\320\277\320\276\321\201\320\273\321\203\320\263", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AccountForm: public Ui_AccountForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCOUNTFORM_H
