/********************************************************************************
** Form generated from reading UI file 'registration.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTRATION_H
#define UI_REGISTRATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Registration
{
public:
    QLabel *label;
    QPushButton *cancel_btn;
    QPushButton *register_btn;
    QPushButton *send_code;
    QLineEdit *code;
    QLabel *label_27;
    QLabel *label_28;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_31;
    QLineEdit *nick;
    QLineEdit *pass;
    QLineEdit *conf_pass;
    QLineEdit *email;
    QLabel *nick_err;
    QLabel *pass_err;
    QLabel *conf_pass_err;
    QLabel *email_err;
    QLabel *code_err;
    QLabel *label_37;
    QLabel *send_code_err;
    QLabel *timer_text;
    QLabel *timer_err;
    QLabel *result_reg;

    void setupUi(QWidget *Registration)
    {
        if (Registration->objectName().isEmpty())
            Registration->setObjectName("Registration");
        Registration->resize(556, 581);
        label = new QLabel(Registration);
        label->setObjectName("label");
        label->setGeometry(QRect(40, 40, 151, 41));
        QFont font;
        font.setPointSize(18);
        label->setFont(font);
        cancel_btn = new QPushButton(Registration);
        cancel_btn->setObjectName("cancel_btn");
        cancel_btn->setGeometry(QRect(180, 510, 91, 31));
        register_btn = new QPushButton(Registration);
        register_btn->setObjectName("register_btn");
        register_btn->setEnabled(true);
        register_btn->setGeometry(QRect(40, 510, 121, 31));
        send_code = new QPushButton(Registration);
        send_code->setObjectName("send_code");
        send_code->setGeometry(QRect(40, 430, 131, 31));
        code = new QLineEdit(Registration);
        code->setObjectName("code");
        code->setGeometry(QRect(170, 360, 200, 31));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(code->sizePolicy().hasHeightForWidth());
        code->setSizePolicy(sizePolicy);
        code->setMinimumSize(QSize(200, 31));
        label_27 = new QLabel(Registration);
        label_27->setObjectName("label_27");
        label_27->setGeometry(QRect(40, 360, 121, 31));
        label_28 = new QLabel(Registration);
        label_28->setObjectName("label_28");
        label_28->setGeometry(QRect(40, 120, 86, 31));
        label_29 = new QLabel(Registration);
        label_29->setObjectName("label_29");
        label_29->setGeometry(QRect(40, 180, 86, 31));
        label_30 = new QLabel(Registration);
        label_30->setObjectName("label_30");
        label_30->setGeometry(QRect(40, 230, 121, 41));
        label_31 = new QLabel(Registration);
        label_31->setObjectName("label_31");
        label_31->setGeometry(QRect(40, 290, 86, 41));
        nick = new QLineEdit(Registration);
        nick->setObjectName("nick");
        nick->setGeometry(QRect(170, 120, 200, 31));
        sizePolicy.setHeightForWidth(nick->sizePolicy().hasHeightForWidth());
        nick->setSizePolicy(sizePolicy);
        nick->setMinimumSize(QSize(200, 31));
        pass = new QLineEdit(Registration);
        pass->setObjectName("pass");
        pass->setGeometry(QRect(170, 180, 200, 31));
        sizePolicy.setHeightForWidth(pass->sizePolicy().hasHeightForWidth());
        pass->setSizePolicy(sizePolicy);
        pass->setMinimumSize(QSize(200, 31));
        pass->setEchoMode(QLineEdit::Password);
        conf_pass = new QLineEdit(Registration);
        conf_pass->setObjectName("conf_pass");
        conf_pass->setGeometry(QRect(170, 240, 200, 31));
        sizePolicy.setHeightForWidth(conf_pass->sizePolicy().hasHeightForWidth());
        conf_pass->setSizePolicy(sizePolicy);
        conf_pass->setMinimumSize(QSize(200, 31));
        conf_pass->setEchoMode(QLineEdit::Password);
        email = new QLineEdit(Registration);
        email->setObjectName("email");
        email->setGeometry(QRect(170, 300, 200, 31));
        sizePolicy.setHeightForWidth(email->sizePolicy().hasHeightForWidth());
        email->setSizePolicy(sizePolicy);
        email->setMinimumSize(QSize(200, 31));
        nick_err = new QLabel(Registration);
        nick_err->setObjectName("nick_err");
        nick_err->setGeometry(QRect(410, 120, 131, 31));
        nick_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        pass_err = new QLabel(Registration);
        pass_err->setObjectName("pass_err");
        pass_err->setGeometry(QRect(410, 180, 131, 31));
        pass_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        conf_pass_err = new QLabel(Registration);
        conf_pass_err->setObjectName("conf_pass_err");
        conf_pass_err->setGeometry(QRect(410, 240, 131, 31));
        conf_pass_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        email_err = new QLabel(Registration);
        email_err->setObjectName("email_err");
        email_err->setGeometry(QRect(410, 300, 131, 31));
        email_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        code_err = new QLabel(Registration);
        code_err->setObjectName("code_err");
        code_err->setGeometry(QRect(410, 360, 131, 31));
        code_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        label_37 = new QLabel(Registration);
        label_37->setObjectName("label_37");
        label_37->setGeometry(QRect(190, 420, 221, 41));
        QFont font1;
        font1.setItalic(true);
        label_37->setFont(font1);
        send_code_err = new QLabel(Registration);
        send_code_err->setObjectName("send_code_err");
        send_code_err->setGeometry(QRect(410, 420, 131, 31));
        send_code_err->setStyleSheet(QString::fromUtf8(""));
        timer_text = new QLabel(Registration);
        timer_text->setObjectName("timer_text");
        timer_text->setGeometry(QRect(190, 470, 191, 31));
        timer_text->setStyleSheet(QString::fromUtf8(""));
        timer_err = new QLabel(Registration);
        timer_err->setObjectName("timer_err");
        timer_err->setGeometry(QRect(410, 470, 111, 31));
        timer_err->setStyleSheet(QString::fromUtf8(""));
        result_reg = new QLabel(Registration);
        result_reg->setObjectName("result_reg");
        result_reg->setGeometry(QRect(300, 510, 211, 31));
        result_reg->setStyleSheet(QString::fromUtf8("color: green;"));

        retranslateUi(Registration);

        QMetaObject::connectSlotsByName(Registration);
    } // setupUi

    void retranslateUi(QWidget *Registration)
    {
        Registration->setWindowTitle(QCoreApplication::translate("Registration", "\320\240\320\265\321\224\321\201\321\202\321\200\320\260\321\206\321\226\321\217", nullptr));
        label->setText(QCoreApplication::translate("Registration", "\320\240\320\265\321\224\321\201\321\202\321\200\320\260\321\206\321\226\321\217", nullptr));
        cancel_btn->setText(QCoreApplication::translate("Registration", "\320\235\320\260\320\267\320\260\320\264", nullptr));
        register_btn->setText(QCoreApplication::translate("Registration", "\320\227\320\260\321\200\320\265\321\224\321\201\321\202\321\200\321\203\320\262\320\260\321\202\320\270", nullptr));
        send_code->setText(QCoreApplication::translate("Registration", "\320\222\321\226\320\264\320\277\321\200\320\260\320\262\320\270\321\202\320\270 \320\272\320\276\320\264", nullptr));
        label_27->setText(QCoreApplication::translate("Registration", "\320\232\320\276\320\264 \321\200\320\265\321\224\321\201\321\202\321\200\320\260\321\206\321\226\321\227 :", nullptr));
        label_28->setText(QCoreApplication::translate("Registration", "\320\235\321\226\320\272 :", nullptr));
        label_29->setText(QCoreApplication::translate("Registration", "\320\237\320\260\321\200\320\276\320\273\321\214 :", nullptr));
        label_30->setText(QCoreApplication::translate("Registration", "\320\237\321\226\320\264\321\202\320\262\320\265\321\200\320\264\320\266\320\265\320\275\320\275\321\217 \n"
"\320\277\320\260\321\200\320\276\320\273\321\216 :", nullptr));
        label_31->setText(QCoreApplication::translate("Registration", "\320\225\320\273\320\265\320\272\321\202\321\200\320\276\320\275\320\275\320\260\n"
"\320\277\320\276\321\210\321\202\320\260 :", nullptr));
        nick_err->setText(QString());
        pass_err->setText(QString());
        conf_pass_err->setText(QString());
        email_err->setText(QString());
        code_err->setText(QString());
        label_37->setText(QCoreApplication::translate("Registration", "(\320\264\320\273\321\217 \320\262\321\226\320\264\320\277\321\200\320\260\320\262\320\272\320\270 \320\272\320\276\320\264\321\203 \320\262\320\262\320\265\320\264\321\226\321\202\321\214\n"
"\320\265\320\273\320\265\320\272\321\202\321\200\320\276\320\275\320\275\321\203 \320\260\320\264\321\200\320\265\321\201\321\203)", nullptr));
        send_code_err->setText(QString());
        timer_text->setText(QString());
        timer_err->setText(QString());
        result_reg->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Registration: public Ui_Registration {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTRATION_H
