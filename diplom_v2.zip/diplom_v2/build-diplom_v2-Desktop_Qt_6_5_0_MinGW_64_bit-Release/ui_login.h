/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QWidget *centralwidget;
    QLineEdit *pass;
    QLabel *pass_err;
    QPushButton *pushButton;
    QLabel *label_4;
    QLabel *label_3;
    QLabel *label;
    QLabel *sign_in_err;
    QLineEdit *nick;
    QLabel *nick_err;
    QLabel *label_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QLabel *label_5;
    QMenuBar *menubar;

    void setupUi(QMainWindow *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName("Login");
        Login->resize(521, 514);
        centralwidget = new QWidget(Login);
        centralwidget->setObjectName("centralwidget");
        pass = new QLineEdit(centralwidget);
        pass->setObjectName("pass");
        pass->setGeometry(QRect(140, 170, 171, 31));
        pass->setEchoMode(QLineEdit::Password);
        pass_err = new QLabel(centralwidget);
        pass_err->setObjectName("pass_err");
        pass_err->setGeometry(QRect(330, 171, 121, 30));
        pass_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(40, 230, 91, 31));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(50, 170, 63, 20));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(50, 120, 81, 20));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(40, 30, 301, 41));
        QFont font;
        font.setPointSize(18);
        label->setFont(font);
        sign_in_err = new QLabel(centralwidget);
        sign_in_err->setObjectName("sign_in_err");
        sign_in_err->setGeometry(QRect(150, 230, 201, 30));
        sign_in_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        nick = new QLineEdit(centralwidget);
        nick->setObjectName("nick");
        nick->setGeometry(QRect(140, 110, 171, 31));
        nick_err = new QLabel(centralwidget);
        nick_err->setObjectName("nick_err");
        nick_err->setGeometry(QRect(330, 111, 121, 30));
        nick_err->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(40, 300, 371, 21));
        QFont font1;
        font1.setItalic(true);
        label_2->setFont(font1);
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(40, 330, 141, 31));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(40, 420, 141, 31));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(40, 390, 371, 21));
        label_5->setFont(font1);
        Login->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Login);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 521, 26));
        Login->setMenuBar(menubar);

        retranslateUi(Login);

        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QMainWindow *Login)
    {
        Login->setWindowTitle(QCoreApplication::translate("Login", "\320\233\320\276\320\263\321\226\320\275", nullptr));
        pass_err->setText(QString());
        pushButton->setText(QCoreApplication::translate("Login", "\320\243\320\262\321\226\320\271\321\202\320\270", nullptr));
        label_4->setText(QCoreApplication::translate("Login", "\320\237\320\260\321\200\320\276\320\273\321\214", nullptr));
        label_3->setText(QCoreApplication::translate("Login", "\320\235\321\226\320\272 ", nullptr));
        label->setText(QCoreApplication::translate("Login", "\320\222\321\205\321\226\320\264 \320\262 \321\201\320\270\321\201\321\202\320\265\320\274\321\203", nullptr));
        sign_in_err->setText(QString());
        nick_err->setText(QString());
        label_2->setText(QCoreApplication::translate("Login", "\320\257\320\272\321\211\320\276 \321\203 \320\262\320\260\321\201 \320\275\320\265\320\274\320\260\321\224 \320\276\320\261\320\273\321\226\320\272\320\276\320\262\320\276\320\263\320\276 \320\267\320\260\320\277\320\270\321\201\321\203, \320\267\320\260\321\200\320\265\321\224\321\201\321\202\321\200\321\203\320\271\321\202\320\265\321\201\321\217", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Login", "\320\227\320\260\321\200\320\265\321\224\321\201\321\202\321\200\321\203\320\262\320\260\321\202\320\270\321\201\321\217", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Login", "\320\222\321\226\320\264\320\275\320\276\320\262\320\270\321\202\320\270 \320\277\320\260\321\200\320\276\320\273\321\214", nullptr));
        label_5->setText(QCoreApplication::translate("Login", "\320\257\320\272\321\211\320\276 \320\267\320\260\320\261\321\203\320\273\320\270 \320\277\320\260\321\200\320\276\320\273\321\214 \321\207\320\265\321\200\320\265\320\267 \320\277\320\276\321\210\321\202\321\203 \320\274\320\276\320\266\320\275\320\260 \320\262\321\226\320\264\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
