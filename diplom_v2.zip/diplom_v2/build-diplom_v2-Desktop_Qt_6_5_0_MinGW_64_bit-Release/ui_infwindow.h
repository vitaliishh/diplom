/********************************************************************************
** Form generated from reading UI file 'infwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INFWINDOW_H
#define UI_INFWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_InfWindow
{
public:
    QAction *action;
    QAction *action_2;
    QAction *action_3;
    QAction *action_4;
    QAction *action_5;
    QAction *action_6;
    QAction *action_7;
    QAction *action_8;
    QAction *action_9;
    QAction *action_10;
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QStackedWidget *stackedWidget;
    QWidget *page1;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QPushButton *add;
    QPushButton *update;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QTableWidget *tableWidget;
    QWidget *voidPage;
    QGridLayout *gridLayout_10;
    QLabel *label_18;
    QWidget *page5;
    QGridLayout *gridLayout_4;
    QLabel *label_13;
    QPushButton *pushButton_6;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_8;
    QLabel *label_2;
    QDateEdit *dateFilter1;
    QSpacerItem *horizontalSpacer_7;
    QLabel *label_14;
    QDateEdit *dateFilter2;
    QTableWidget *warehouse_table;
    QPushButton *pushButton_5;
    QComboBox *filterWarehouse;
    QLineEdit *search_by_name;
    QSpacerItem *horizontalSpacer_5;
    QWidget *product_na;
    QGridLayout *gridLayout_9;
    QLabel *label_16;
    QTableWidget *product_na_table;
    QPushButton *pushButton_10;
    QSpacerItem *horizontalSpacer_9;
    QWidget *organization_edit;
    QGridLayout *gridLayout_7;
    QSpacerItem *horizontalSpacer_8;
    QTableView *organization_edit_table;
    QLabel *label_15;
    QPushButton *pushButton_7;
    QPushButton *pushButton_9;
    QWidget *page2;
    QGridLayout *gridLayout_5;
    QLabel *label_3;
    QTableWidget *pay_instruction_table;
    QPushButton *pushButton_3;
    QSpacerItem *horizontalSpacer_3;
    QWidget *page3;
    QGridLayout *gridLayout_6;
    QLabel *label_4;
    QTableWidget *attorney_power_table;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_2;
    QWidget *organization;
    QLabel *label_5;
    QLabel *err1;
    QLabel *err2;
    QLabel *err3;
    QLabel *err4;
    QLabel *err5;
    QLabel *err6;
    QLabel *final_err;
    QPushButton *pushButton_2;
    QLabel *label_11;
    QLineEdit *lineEdit_6;
    QLabel *label_10;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_4;
    QLabel *label_9;
    QLabel *label_8;
    QLineEdit *lineEdit_3;
    QLabel *label_7;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_1;
    QLabel *label_6;
    QWidget *page4;
    QGridLayout *gridLayout_8;
    QLabel *label_12;
    QTableWidget *sales_invoice;
    QPushButton *pushButton_4;
    QSpacerItem *horizontalSpacer_4;
    QMenuBar *menubar;
    QMenu *menu;
    QMenu *menu_2;
    QMenu *menu_3;
    QMenu *menu_4;
    QMenu *menu_5;
    QMenu *menu_6;

    void setupUi(QMainWindow *InfWindow)
    {
        if (InfWindow->objectName().isEmpty())
            InfWindow->setObjectName("InfWindow");
        InfWindow->resize(785, 628);
        action = new QAction(InfWindow);
        action->setObjectName("action");
        QIcon icon;
        QString iconThemeName = QString::fromUtf8("document-open");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QString::fromUtf8(":/img/res/btn/free-icon-expand-8975040.png"), QSize(), QIcon::Normal, QIcon::Off);
        }
        action->setIcon(icon);
        action_2 = new QAction(InfWindow);
        action_2->setObjectName("action_2");
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/img/res/btn/free-icon-expand-8975040.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_2->setIcon(icon1);
        action_3 = new QAction(InfWindow);
        action_3->setObjectName("action_3");
        action_3->setIcon(icon1);
        action_4 = new QAction(InfWindow);
        action_4->setObjectName("action_4");
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/img/res/btn/free-icon-plus-3856900.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_4->setIcon(icon2);
        action_5 = new QAction(InfWindow);
        action_5->setObjectName("action_5");
        action_5->setIcon(icon1);
        action_6 = new QAction(InfWindow);
        action_6->setObjectName("action_6");
        action_6->setIcon(icon1);
        action_7 = new QAction(InfWindow);
        action_7->setObjectName("action_7");
        QIcon icon3;
        iconThemeName = QString::fromUtf8("accessories-character-map");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon3 = QIcon::fromTheme(iconThemeName);
        } else {
            icon3.addFile(QString::fromUtf8(":/img/res/btn/free-icon-edit-4007772.png"), QSize(), QIcon::Normal, QIcon::Off);
        }
        action_7->setIcon(icon3);
        action_8 = new QAction(InfWindow);
        action_8->setObjectName("action_8");
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/img/res/menu/free-icon-packing-list-2897653.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_8->setIcon(icon4);
        action_9 = new QAction(InfWindow);
        action_9->setObjectName("action_9");
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/img/res/menu/free-icon-box-157285.png"), QSize(), QIcon::Normal, QIcon::Off);
        action_9->setIcon(icon5);
        action_10 = new QAction(InfWindow);
        action_10->setObjectName("action_10");
        action_10->setIcon(icon2);
        centralwidget = new QWidget(InfWindow);
        centralwidget->setObjectName("centralwidget");
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName("gridLayout_3");
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName("stackedWidget");
        page1 = new QWidget();
        page1->setObjectName("page1");
        gridLayout_2 = new QGridLayout(page1);
        gridLayout_2->setObjectName("gridLayout_2");
        gridLayout = new QGridLayout();
        gridLayout->setObjectName("gridLayout");
        add = new QPushButton(page1);
        add->setObjectName("add");

        gridLayout->addWidget(add, 0, 0, 1, 1);

        update = new QPushButton(page1);
        update->setObjectName("update");

        gridLayout->addWidget(update, 0, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout, 2, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(600, 28, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 2, 1, 1, 1);

        label = new QLabel(page1);
        label->setObjectName("label");
        QFont font;
        font.setPointSize(14);
        font.setBold(false);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        label->setMargin(10);

        gridLayout_2->addWidget(label, 0, 0, 1, 2);

        tableWidget = new QTableWidget(page1);
        tableWidget->setObjectName("tableWidget");
        QFont font1;
        font1.setPointSize(10);
        tableWidget->setFont(font1);

        gridLayout_2->addWidget(tableWidget, 1, 0, 1, 2);

        stackedWidget->addWidget(page1);
        voidPage = new QWidget();
        voidPage->setObjectName("voidPage");
        gridLayout_10 = new QGridLayout(voidPage);
        gridLayout_10->setObjectName("gridLayout_10");
        label_18 = new QLabel(voidPage);
        label_18->setObjectName("label_18");
        QFont font2;
        font2.setPointSize(16);
        label_18->setFont(font2);
        label_18->setStyleSheet(QString::fromUtf8("color: #afb3b0;"));
        label_18->setAlignment(Qt::AlignCenter);

        gridLayout_10->addWidget(label_18, 0, 0, 1, 1);

        stackedWidget->addWidget(voidPage);
        page5 = new QWidget();
        page5->setObjectName("page5");
        gridLayout_4 = new QGridLayout(page5);
        gridLayout_4->setObjectName("gridLayout_4");
        label_13 = new QLabel(page5);
        label_13->setObjectName("label_13");
        label_13->setFont(font);
        label_13->setAlignment(Qt::AlignCenter);
        label_13->setMargin(0);

        gridLayout_4->addWidget(label_13, 0, 0, 1, 8);

        pushButton_6 = new QPushButton(page5);
        pushButton_6->setObjectName("pushButton_6");

        gridLayout_4->addWidget(pushButton_6, 1, 0, 1, 2);

        horizontalSpacer_6 = new QSpacerItem(144, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_6, 1, 4, 1, 1);

        pushButton_8 = new QPushButton(page5);
        pushButton_8->setObjectName("pushButton_8");

        gridLayout_4->addWidget(pushButton_8, 1, 5, 1, 1);

        label_2 = new QLabel(page5);
        label_2->setObjectName("label_2");

        gridLayout_4->addWidget(label_2, 1, 6, 1, 1);

        dateFilter1 = new QDateEdit(page5);
        dateFilter1->setObjectName("dateFilter1");
        dateFilter1->setDateTime(QDateTime(QDate(1995, 12, 30), QTime(4, 0, 0)));

        gridLayout_4->addWidget(dateFilter1, 1, 7, 1, 1);

        horizontalSpacer_7 = new QSpacerItem(144, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_7, 2, 4, 1, 1);

        label_14 = new QLabel(page5);
        label_14->setObjectName("label_14");

        gridLayout_4->addWidget(label_14, 2, 6, 1, 1);

        dateFilter2 = new QDateEdit(page5);
        dateFilter2->setObjectName("dateFilter2");
        dateFilter2->setDateTime(QDateTime(QDate(2049, 12, 30), QTime(8, 0, 0)));

        gridLayout_4->addWidget(dateFilter2, 2, 7, 1, 1);

        warehouse_table = new QTableWidget(page5);
        warehouse_table->setObjectName("warehouse_table");
        warehouse_table->setFont(font1);

        gridLayout_4->addWidget(warehouse_table, 3, 0, 1, 8);

        pushButton_5 = new QPushButton(page5);
        pushButton_5->setObjectName("pushButton_5");

        gridLayout_4->addWidget(pushButton_5, 4, 0, 1, 1);

        filterWarehouse = new QComboBox(page5);
        filterWarehouse->addItem(QString());
        filterWarehouse->addItem(QString());
        filterWarehouse->addItem(QString());
        filterWarehouse->setObjectName("filterWarehouse");

        gridLayout_4->addWidget(filterWarehouse, 1, 2, 1, 1);

        search_by_name = new QLineEdit(page5);
        search_by_name->setObjectName("search_by_name");
        search_by_name->setMinimumSize(QSize(200, 0));
        search_by_name->setMaximumSize(QSize(300, 16777215));

        gridLayout_4->addWidget(search_by_name, 2, 0, 1, 3);

        horizontalSpacer_5 = new QSpacerItem(645, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_5, 4, 2, 1, 6);

        stackedWidget->addWidget(page5);
        product_na = new QWidget();
        product_na->setObjectName("product_na");
        gridLayout_9 = new QGridLayout(product_na);
        gridLayout_9->setObjectName("gridLayout_9");
        label_16 = new QLabel(product_na);
        label_16->setObjectName("label_16");
        label_16->setFont(font);
        label_16->setAlignment(Qt::AlignCenter);
        label_16->setMargin(10);

        gridLayout_9->addWidget(label_16, 0, 0, 1, 2);

        product_na_table = new QTableWidget(product_na);
        product_na_table->setObjectName("product_na_table");
        product_na_table->setFont(font1);

        gridLayout_9->addWidget(product_na_table, 1, 0, 1, 2);

        pushButton_10 = new QPushButton(product_na);
        pushButton_10->setObjectName("pushButton_10");
        QFont font3;
        font3.setPointSize(9);
        pushButton_10->setFont(font3);

        gridLayout_9->addWidget(pushButton_10, 2, 0, 1, 1);

        horizontalSpacer_9 = new QSpacerItem(638, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_9->addItem(horizontalSpacer_9, 2, 1, 1, 1);

        stackedWidget->addWidget(product_na);
        organization_edit = new QWidget();
        organization_edit->setObjectName("organization_edit");
        gridLayout_7 = new QGridLayout(organization_edit);
        gridLayout_7->setObjectName("gridLayout_7");
        horizontalSpacer_8 = new QSpacerItem(638, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_7->addItem(horizontalSpacer_8, 2, 2, 1, 1);

        organization_edit_table = new QTableView(organization_edit);
        organization_edit_table->setObjectName("organization_edit_table");
        organization_edit_table->setFont(font1);

        gridLayout_7->addWidget(organization_edit_table, 1, 0, 1, 3);

        label_15 = new QLabel(organization_edit);
        label_15->setObjectName("label_15");
        label_15->setFont(font);
        label_15->setAlignment(Qt::AlignCenter);
        label_15->setMargin(10);

        gridLayout_7->addWidget(label_15, 0, 0, 1, 3);

        pushButton_7 = new QPushButton(organization_edit);
        pushButton_7->setObjectName("pushButton_7");

        gridLayout_7->addWidget(pushButton_7, 2, 0, 1, 1);

        pushButton_9 = new QPushButton(organization_edit);
        pushButton_9->setObjectName("pushButton_9");

        gridLayout_7->addWidget(pushButton_9, 2, 1, 1, 1);

        stackedWidget->addWidget(organization_edit);
        page2 = new QWidget();
        page2->setObjectName("page2");
        page2->setFont(font1);
        gridLayout_5 = new QGridLayout(page2);
        gridLayout_5->setObjectName("gridLayout_5");
        label_3 = new QLabel(page2);
        label_3->setObjectName("label_3");
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignCenter);
        label_3->setMargin(10);

        gridLayout_5->addWidget(label_3, 0, 0, 1, 2);

        pay_instruction_table = new QTableWidget(page2);
        pay_instruction_table->setObjectName("pay_instruction_table");

        gridLayout_5->addWidget(pay_instruction_table, 1, 0, 1, 2);

        pushButton_3 = new QPushButton(page2);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setFont(font3);

        gridLayout_5->addWidget(pushButton_3, 2, 0, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(717, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer_3, 2, 1, 1, 1);

        stackedWidget->addWidget(page2);
        page3 = new QWidget();
        page3->setObjectName("page3");
        gridLayout_6 = new QGridLayout(page3);
        gridLayout_6->setObjectName("gridLayout_6");
        label_4 = new QLabel(page3);
        label_4->setObjectName("label_4");
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignCenter);
        label_4->setMargin(10);

        gridLayout_6->addWidget(label_4, 0, 0, 1, 2);

        attorney_power_table = new QTableWidget(page3);
        attorney_power_table->setObjectName("attorney_power_table");
        attorney_power_table->setFont(font1);

        gridLayout_6->addWidget(attorney_power_table, 1, 0, 1, 2);

        pushButton = new QPushButton(page3);
        pushButton->setObjectName("pushButton");

        gridLayout_6->addWidget(pushButton, 2, 0, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(717, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_6->addItem(horizontalSpacer_2, 2, 1, 1, 1);

        stackedWidget->addWidget(page3);
        organization = new QWidget();
        organization->setObjectName("organization");
        label_5 = new QLabel(organization);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(0, 10, 151, 50));
        label_5->setMaximumSize(QSize(16777215, 50));
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignCenter);
        label_5->setMargin(10);
        err1 = new QLabel(organization);
        err1->setObjectName("err1");
        err1->setGeometry(QRect(480, 90, 125, 20));
        err1->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        err2 = new QLabel(organization);
        err2->setObjectName("err2");
        err2->setGeometry(QRect(480, 140, 125, 20));
        err2->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        err3 = new QLabel(organization);
        err3->setObjectName("err3");
        err3->setGeometry(QRect(480, 190, 125, 20));
        err3->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        err4 = new QLabel(organization);
        err4->setObjectName("err4");
        err4->setGeometry(QRect(480, 244, 125, 20));
        err4->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        err5 = new QLabel(organization);
        err5->setObjectName("err5");
        err5->setGeometry(QRect(480, 298, 125, 20));
        err5->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        err6 = new QLabel(organization);
        err6->setObjectName("err6");
        err6->setGeometry(QRect(480, 355, 125, 20));
        err6->setStyleSheet(QString::fromUtf8("color: #cf2323;"));
        final_err = new QLabel(organization);
        final_err->setObjectName("final_err");
        final_err->setGeometry(QRect(130, 435, 125, 20));
        final_err->setStyleSheet(QString::fromUtf8("color: green;"));
        pushButton_2 = new QPushButton(organization);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(20, 430, 93, 29));
        label_11 = new QLabel(organization);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(20, 340, 134, 61));
        lineEdit_6 = new QLineEdit(organization);
        lineEdit_6->setObjectName("lineEdit_6");
        lineEdit_6->setGeometry(QRect(110, 350, 341, 30));
        lineEdit_6->setMinimumSize(QSize(0, 30));
        label_10 = new QLabel(organization);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(20, 290, 55, 20));
        lineEdit_5 = new QLineEdit(organization);
        lineEdit_5->setObjectName("lineEdit_5");
        lineEdit_5->setGeometry(QRect(110, 294, 341, 30));
        lineEdit_5->setMinimumSize(QSize(0, 30));
        lineEdit_4 = new QLineEdit(organization);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setGeometry(QRect(110, 240, 341, 30));
        lineEdit_4->setMinimumSize(QSize(0, 30));
        label_9 = new QLabel(organization);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(20, 240, 58, 20));
        label_8 = new QLabel(organization);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(20, 190, 60, 20));
        lineEdit_3 = new QLineEdit(organization);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setGeometry(QRect(110, 190, 341, 30));
        lineEdit_3->setMinimumSize(QSize(0, 30));
        label_7 = new QLabel(organization);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(20, 140, 50, 20));
        lineEdit_2 = new QLineEdit(organization);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(110, 140, 341, 30));
        lineEdit_2->setMinimumSize(QSize(0, 30));
        lineEdit_1 = new QLineEdit(organization);
        lineEdit_1->setObjectName("lineEdit_1");
        lineEdit_1->setGeometry(QRect(110, 90, 341, 30));
        lineEdit_1->setMinimumSize(QSize(0, 30));
        label_6 = new QLabel(organization);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(20, 90, 42, 20));
        stackedWidget->addWidget(organization);
        page4 = new QWidget();
        page4->setObjectName("page4");
        gridLayout_8 = new QGridLayout(page4);
        gridLayout_8->setObjectName("gridLayout_8");
        label_12 = new QLabel(page4);
        label_12->setObjectName("label_12");
        label_12->setFont(font);
        label_12->setAlignment(Qt::AlignCenter);
        label_12->setMargin(10);

        gridLayout_8->addWidget(label_12, 0, 0, 1, 2);

        sales_invoice = new QTableWidget(page4);
        sales_invoice->setObjectName("sales_invoice");
        sales_invoice->setFont(font1);

        gridLayout_8->addWidget(sales_invoice, 1, 0, 1, 2);

        pushButton_4 = new QPushButton(page4);
        pushButton_4->setObjectName("pushButton_4");

        gridLayout_8->addWidget(pushButton_4, 2, 0, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(717, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_8->addItem(horizontalSpacer_4, 2, 1, 1, 1);

        stackedWidget->addWidget(page4);

        gridLayout_3->addWidget(stackedWidget, 0, 0, 1, 1);

        InfWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(InfWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 785, 26));
        menubar->setStyleSheet(QString::fromUtf8("QMenuBar { background-color: #fafaff; color: black; }\n"
""));
        menu = new QMenu(menubar);
        menu->setObjectName("menu");
        menu_2 = new QMenu(menubar);
        menu_2->setObjectName("menu_2");
        menu_3 = new QMenu(menubar);
        menu_3->setObjectName("menu_3");
        menu_4 = new QMenu(menubar);
        menu_4->setObjectName("menu_4");
        menu_5 = new QMenu(menubar);
        menu_5->setObjectName("menu_5");
        menu_6 = new QMenu(menubar);
        menu_6->setObjectName("menu_6");
        InfWindow->setMenuBar(menubar);

        menubar->addAction(menu_3->menuAction());
        menubar->addAction(menu->menuAction());
        menubar->addAction(menu_2->menuAction());
        menubar->addAction(menu_4->menuAction());
        menubar->addAction(menu_5->menuAction());
        menubar->addAction(menu_6->menuAction());
        menu->addAction(action_2);
        menu_2->addAction(action_3);
        menu_3->addAction(action);
        menu_3->addAction(action_10);
        menu_4->addAction(action_5);
        menu_5->addAction(action_6);
        menu_5->addAction(action_8);
        menu_5->addAction(action_9);
        menu_6->addAction(action_4);
        menu_6->addAction(action_7);

        retranslateUi(InfWindow);

        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(InfWindow);
    } // setupUi

    void retranslateUi(QMainWindow *InfWindow)
    {
        InfWindow->setWindowTitle(QCoreApplication::translate("InfWindow", "\320\240\320\276\320\261\320\276\321\207\320\260 \320\276\320\261\320\273\320\260\321\201\321\202\321\214", nullptr));
        action->setText(QCoreApplication::translate("InfWindow", "\320\222\321\226\320\264\320\272\321\200\320\270\321\202\320\270", nullptr));
        action_2->setText(QCoreApplication::translate("InfWindow", "\320\222\321\226\320\264\320\272\321\200\320\270\321\202\320\270", nullptr));
        action_3->setText(QCoreApplication::translate("InfWindow", "\320\222\321\226\320\264\320\272\321\200\320\270\321\202\320\270", nullptr));
        action_4->setText(QCoreApplication::translate("InfWindow", "\320\224\320\276\320\264\320\260\321\202\320\270", nullptr));
        action_5->setText(QCoreApplication::translate("InfWindow", "\320\222\321\226\320\264\320\272\321\200\320\270\321\202\320\270", nullptr));
        action_6->setText(QCoreApplication::translate("InfWindow", "\320\222\321\226\320\264\320\272\321\200\320\270\321\202\320\270", nullptr));
        action_7->setText(QCoreApplication::translate("InfWindow", "\320\240\320\265\320\264\320\260\320\263\321\203\320\262\320\260\321\202\320\270", nullptr));
        action_8->setText(QCoreApplication::translate("InfWindow", "\320\235\320\260\320\272\320\273\320\260\320\264\320\275\320\260 \320\275\320\260 \320\262\320\270\320\264\320\260\321\207\321\203", nullptr));
        action_9->setText(QCoreApplication::translate("InfWindow", "\320\222\320\270\320\264\320\260\321\207\320\260 \321\202\320\276\320\262\320\260\321\200\321\226\320\262", nullptr));
        action_10->setText(QCoreApplication::translate("InfWindow", "\320\224\320\276\320\264\320\260\321\202\320\270", nullptr));
        add->setText(QCoreApplication::translate("InfWindow", "\320\224\320\276\320\264\320\260\321\202\320\270", nullptr));
        update->setText(QCoreApplication::translate("InfWindow", "\320\236\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
        label->setText(QCoreApplication::translate("InfWindow", "\320\240\320\260\321\205\321\203\320\275\320\276\320\272 \320\275\320\260 \320\276\320\277\320\273\320\260\321\202\321\203", nullptr));
        label_18->setText(QCoreApplication::translate("InfWindow", "\320\222\320\270\320\261\320\265\321\200\321\226\321\202\321\214 \320\262\320\272\320\273\320\260\320\264\320\272\321\203", nullptr));
        label_13->setText(QCoreApplication::translate("InfWindow", "\320\241\320\272\320\273\320\260\320\264", nullptr));
        pushButton_6->setText(QCoreApplication::translate("InfWindow", "\320\237\320\276\321\210\321\203\320\272", nullptr));
        pushButton_8->setText(QCoreApplication::translate("InfWindow", "\320\237\320\276\321\210\321\203\320\272 \320\277\320\276 \320\264\320\260\321\202\321\226", nullptr));
        label_2->setText(QCoreApplication::translate("InfWindow", "\320\222\321\226\320\264", nullptr));
        label_14->setText(QCoreApplication::translate("InfWindow", "\320\237\320\276", nullptr));
        pushButton_5->setText(QCoreApplication::translate("InfWindow", "\320\236\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
        filterWarehouse->setItemText(0, QCoreApplication::translate("InfWindow", "\320\237\320\276 \320\275\320\260\320\267\320\262\321\226 \321\202\320\276\320\262\320\260\321\200\321\203", nullptr));
        filterWarehouse->setItemText(1, QCoreApplication::translate("InfWindow", "\320\237\320\276 \320\275\320\276\320\274\320\265\321\200\321\203 \321\202\320\276\320\262\320\260\321\200\321\203", nullptr));
        filterWarehouse->setItemText(2, QCoreApplication::translate("InfWindow", "\320\237\320\276 \320\275\320\276\320\274\320\265\321\200\321\203 \320\275\320\260\320\272\320\273\320\260\320\264\320\275\320\276\321\227", nullptr));

        label_16->setText(QCoreApplication::translate("InfWindow", "\320\222\320\270\320\264\320\260\321\207\320\260 \321\202\320\276\320\262\320\260\321\200\321\226\320\262", nullptr));
        pushButton_10->setText(QCoreApplication::translate("InfWindow", "\320\236\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
        label_15->setText(QCoreApplication::translate("InfWindow", "\320\240\320\265\320\264\320\260\320\263\321\203\320\262\320\260\321\202\320\270 \320\276\321\200\320\263\320\260\320\275\321\226\320\267\320\260\321\206\321\226\321\227", nullptr));
        pushButton_7->setText(QCoreApplication::translate("InfWindow", "\320\222\320\270\320\264\320\260\320\273\320\270\321\202\320\270", nullptr));
        pushButton_9->setText(QCoreApplication::translate("InfWindow", "\320\236\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
        label_3->setText(QCoreApplication::translate("InfWindow", "\320\237\320\273\320\260\321\202\321\226\320\266\320\275\320\260 \321\226\320\275\321\201\321\202\321\200\321\203\320\272\321\206\321\226\321\217", nullptr));
        pushButton_3->setText(QCoreApplication::translate("InfWindow", "\320\236\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
        label_4->setText(QCoreApplication::translate("InfWindow", "\320\224\320\276\320\262\321\226\321\200\320\265\320\275\321\226\321\201\321\202\321\214", nullptr));
        pushButton->setText(QCoreApplication::translate("InfWindow", "\320\236\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
        label_5->setText(QCoreApplication::translate("InfWindow", "\320\236\321\200\320\263\320\260\320\275\321\226\320\267\320\260\321\206\321\226\321\217", nullptr));
        err1->setText(QString());
        err2->setText(QString());
        err3->setText(QString());
        err4->setText(QString());
        err5->setText(QString());
        err6->setText(QString());
        final_err->setText(QString());
        pushButton_2->setText(QCoreApplication::translate("InfWindow", "\320\241\321\202\320\262\320\276\321\200\320\270\321\202\320\270", nullptr));
        label_11->setText(QCoreApplication::translate("InfWindow", "\320\235\320\260\320\264\320\260\320\262\320\260\321\207  \n"
"\320\277\320\273\320\260\321\202\321\226\320\266\320\275\320\270\321\205 \n"
"\320\277\320\276\321\201\320\273\321\201\321\203\320\263", nullptr));
        label_10->setText(QCoreApplication::translate("InfWindow", "\320\240\320\260\321\205\321\203\320\275\320\276\320\272", nullptr));
        label_9->setText(QCoreApplication::translate("InfWindow", "\320\204\320\224\320\240\320\237\320\236\320\243", nullptr));
        label_8->setText(QCoreApplication::translate("InfWindow", "\320\242\320\265\320\273\320\265\321\204\320\276\320\275", nullptr));
        label_7->setText(QCoreApplication::translate("InfWindow", "\320\220\320\264\321\200\320\265\321\201\320\260", nullptr));
        label_6->setText(QCoreApplication::translate("InfWindow", "\320\235\320\260\320\267\320\262\320\260", nullptr));
        label_12->setText(QCoreApplication::translate("InfWindow", "\320\222\320\270\320\264\320\260\321\202\320\272\320\276\320\262\320\260 \320\275\320\260\320\272\320\273\320\260\320\264\320\275\320\260", nullptr));
        pushButton_4->setText(QCoreApplication::translate("InfWindow", "\320\236\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
        menu->setTitle(QCoreApplication::translate("InfWindow", "\320\237\320\273\320\260\321\202\321\226\320\266\320\275\320\260 \321\226\320\275\321\201\321\202\321\200\321\203\320\272\321\206\321\226\321\217", nullptr));
        menu_2->setTitle(QCoreApplication::translate("InfWindow", "\320\224\320\276\320\262\321\226\321\200\320\265\320\275\321\226\321\201\321\202\321\214", nullptr));
        menu_3->setTitle(QCoreApplication::translate("InfWindow", "\320\240\320\260\321\205\321\203\320\275\320\276\320\272 \320\275\320\260 \320\276\320\277\320\273\320\260\321\202\321\203", nullptr));
        menu_4->setTitle(QCoreApplication::translate("InfWindow", "\320\222\320\270\320\264\320\260\321\202\320\272\320\276\320\262\320\260 \320\275\320\260\320\272\320\273\320\260\320\264\320\275\320\260", nullptr));
        menu_5->setTitle(QCoreApplication::translate("InfWindow", "\320\241\320\272\320\273\320\260\320\264", nullptr));
        menu_6->setTitle(QCoreApplication::translate("InfWindow", "\320\236\321\200\320\263\320\260\320\275\321\226\320\267\320\260\321\206\321\226\321\217", nullptr));
    } // retranslateUi

};

namespace Ui {
    class InfWindow: public Ui_InfWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INFWINDOW_H
