/****************************************************************************
** Meta object code from reading C++ file 'infwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../diplom_v2/infwindow.h"
#include <QtNetwork/QSslPreSharedKeyAuthenticator>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'infwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSInfWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSInfWindowENDCLASS = QtMocHelpers::stringData(
    "InfWindow",
    "activateDatabaseConnection",
    "",
    "onButtonClicked1",
    "val",
    "onButtonClicked2",
    "on_add_clicked",
    "on_update_clicked",
    "on_action_triggered",
    "on_action_2_triggered",
    "on_action_3_triggered",
    "on_action_4_triggered",
    "on_pushButton_2_clicked",
    "on_pushButton_3_clicked",
    "on_pushButton_clicked",
    "on_action_5_triggered",
    "on_pushButton_4_clicked",
    "on_action_6_triggered",
    "on_pushButton_5_clicked",
    "on_pushButton_6_clicked",
    "on_pushButton_8_clicked",
    "on_action_7_triggered",
    "on_pushButton_9_clicked",
    "on_pushButton_7_clicked",
    "on_action_8_triggered",
    "on_action_9_triggered",
    "on_pushButton_10_clicked",
    "on_action_10_triggered"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSInfWindowENDCLASS_t {
    uint offsetsAndSizes[56];
    char stringdata0[10];
    char stringdata1[27];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[4];
    char stringdata5[17];
    char stringdata6[15];
    char stringdata7[18];
    char stringdata8[20];
    char stringdata9[22];
    char stringdata10[22];
    char stringdata11[22];
    char stringdata12[24];
    char stringdata13[24];
    char stringdata14[22];
    char stringdata15[22];
    char stringdata16[24];
    char stringdata17[22];
    char stringdata18[24];
    char stringdata19[24];
    char stringdata20[24];
    char stringdata21[22];
    char stringdata22[24];
    char stringdata23[24];
    char stringdata24[22];
    char stringdata25[22];
    char stringdata26[25];
    char stringdata27[23];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSInfWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSInfWindowENDCLASS_t qt_meta_stringdata_CLASSInfWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 9),  // "InfWindow"
        QT_MOC_LITERAL(10, 26),  // "activateDatabaseConnection"
        QT_MOC_LITERAL(37, 0),  // ""
        QT_MOC_LITERAL(38, 16),  // "onButtonClicked1"
        QT_MOC_LITERAL(55, 3),  // "val"
        QT_MOC_LITERAL(59, 16),  // "onButtonClicked2"
        QT_MOC_LITERAL(76, 14),  // "on_add_clicked"
        QT_MOC_LITERAL(91, 17),  // "on_update_clicked"
        QT_MOC_LITERAL(109, 19),  // "on_action_triggered"
        QT_MOC_LITERAL(129, 21),  // "on_action_2_triggered"
        QT_MOC_LITERAL(151, 21),  // "on_action_3_triggered"
        QT_MOC_LITERAL(173, 21),  // "on_action_4_triggered"
        QT_MOC_LITERAL(195, 23),  // "on_pushButton_2_clicked"
        QT_MOC_LITERAL(219, 23),  // "on_pushButton_3_clicked"
        QT_MOC_LITERAL(243, 21),  // "on_pushButton_clicked"
        QT_MOC_LITERAL(265, 21),  // "on_action_5_triggered"
        QT_MOC_LITERAL(287, 23),  // "on_pushButton_4_clicked"
        QT_MOC_LITERAL(311, 21),  // "on_action_6_triggered"
        QT_MOC_LITERAL(333, 23),  // "on_pushButton_5_clicked"
        QT_MOC_LITERAL(357, 23),  // "on_pushButton_6_clicked"
        QT_MOC_LITERAL(381, 23),  // "on_pushButton_8_clicked"
        QT_MOC_LITERAL(405, 21),  // "on_action_7_triggered"
        QT_MOC_LITERAL(427, 23),  // "on_pushButton_9_clicked"
        QT_MOC_LITERAL(451, 23),  // "on_pushButton_7_clicked"
        QT_MOC_LITERAL(475, 21),  // "on_action_8_triggered"
        QT_MOC_LITERAL(497, 21),  // "on_action_9_triggered"
        QT_MOC_LITERAL(519, 24),  // "on_pushButton_10_clicked"
        QT_MOC_LITERAL(544, 22)   // "on_action_10_triggered"
    },
    "InfWindow",
    "activateDatabaseConnection",
    "",
    "onButtonClicked1",
    "val",
    "onButtonClicked2",
    "on_add_clicked",
    "on_update_clicked",
    "on_action_triggered",
    "on_action_2_triggered",
    "on_action_3_triggered",
    "on_action_4_triggered",
    "on_pushButton_2_clicked",
    "on_pushButton_3_clicked",
    "on_pushButton_clicked",
    "on_action_5_triggered",
    "on_pushButton_4_clicked",
    "on_action_6_triggered",
    "on_pushButton_5_clicked",
    "on_pushButton_6_clicked",
    "on_pushButton_8_clicked",
    "on_action_7_triggered",
    "on_pushButton_9_clicked",
    "on_pushButton_7_clicked",
    "on_action_8_triggered",
    "on_action_9_triggered",
    "on_pushButton_10_clicked",
    "on_action_10_triggered"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSInfWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  164,    2, 0x0a,    1 /* Public */,
       3,    1,  165,    2, 0x08,    2 /* Private */,
       5,    1,  168,    2, 0x08,    4 /* Private */,
       6,    0,  171,    2, 0x08,    6 /* Private */,
       7,    0,  172,    2, 0x08,    7 /* Private */,
       8,    0,  173,    2, 0x08,    8 /* Private */,
       9,    0,  174,    2, 0x08,    9 /* Private */,
      10,    0,  175,    2, 0x08,   10 /* Private */,
      11,    0,  176,    2, 0x08,   11 /* Private */,
      12,    0,  177,    2, 0x08,   12 /* Private */,
      13,    0,  178,    2, 0x08,   13 /* Private */,
      14,    0,  179,    2, 0x08,   14 /* Private */,
      15,    0,  180,    2, 0x08,   15 /* Private */,
      16,    0,  181,    2, 0x08,   16 /* Private */,
      17,    0,  182,    2, 0x08,   17 /* Private */,
      18,    0,  183,    2, 0x08,   18 /* Private */,
      19,    0,  184,    2, 0x08,   19 /* Private */,
      20,    0,  185,    2, 0x08,   20 /* Private */,
      21,    0,  186,    2, 0x08,   21 /* Private */,
      22,    0,  187,    2, 0x08,   22 /* Private */,
      23,    0,  188,    2, 0x08,   23 /* Private */,
      24,    0,  189,    2, 0x08,   24 /* Private */,
      25,    0,  190,    2, 0x08,   25 /* Private */,
      26,    0,  191,    2, 0x08,   26 /* Private */,
      27,    0,  192,    2, 0x08,   27 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject InfWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSInfWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSInfWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSInfWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<InfWindow, std::true_type>,
        // method 'activateDatabaseConnection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onButtonClicked1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'onButtonClicked2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_add_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_update_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_2_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_3_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_4_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_5_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_6_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_5_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_6_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_8_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_7_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_9_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_7_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_8_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_9_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_10_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_action_10_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void InfWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<InfWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->activateDatabaseConnection(); break;
        case 1: _t->onButtonClicked1((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->onButtonClicked2((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->on_add_clicked(); break;
        case 4: _t->on_update_clicked(); break;
        case 5: _t->on_action_triggered(); break;
        case 6: _t->on_action_2_triggered(); break;
        case 7: _t->on_action_3_triggered(); break;
        case 8: _t->on_action_4_triggered(); break;
        case 9: _t->on_pushButton_2_clicked(); break;
        case 10: _t->on_pushButton_3_clicked(); break;
        case 11: _t->on_pushButton_clicked(); break;
        case 12: _t->on_action_5_triggered(); break;
        case 13: _t->on_pushButton_4_clicked(); break;
        case 14: _t->on_action_6_triggered(); break;
        case 15: _t->on_pushButton_5_clicked(); break;
        case 16: _t->on_pushButton_6_clicked(); break;
        case 17: _t->on_pushButton_8_clicked(); break;
        case 18: _t->on_action_7_triggered(); break;
        case 19: _t->on_pushButton_9_clicked(); break;
        case 20: _t->on_pushButton_7_clicked(); break;
        case 21: _t->on_action_8_triggered(); break;
        case 22: _t->on_action_9_triggered(); break;
        case 23: _t->on_pushButton_10_clicked(); break;
        case 24: _t->on_action_10_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject *InfWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InfWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSInfWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int InfWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 25;
    }
    return _id;
}
QT_WARNING_POP
