/********************************************************************************
** Form generated from reading UI file 'products.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRODUCTS_H
#define UI_PRODUCTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_Products
{
public:
    QGridLayout *gridLayout_5;
    QGridLayout *gridLayout_4;
    QLabel *label_4;
    QTableView *tableView;
    QGridLayout *gridLayout_3;
    QPushButton *addProduct;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *name;
    QLineEdit *amount;
    QLabel *label_2;
    QLineEdit *price;
    QLabel *label_3;
    QSpacerItem *horizontalSpacer;
    QGridLayout *gridLayout_2;
    QPushButton *cancel;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *add_error;

    void setupUi(QDialog *Products)
    {
        if (Products->objectName().isEmpty())
            Products->setObjectName("Products");
        Products->resize(819, 634);
        gridLayout_5 = new QGridLayout(Products);
        gridLayout_5->setObjectName("gridLayout_5");
        gridLayout_5->setContentsMargins(20, 0, 20, 20);
        gridLayout_4 = new QGridLayout();
        gridLayout_4->setObjectName("gridLayout_4");
        label_4 = new QLabel(Products);
        label_4->setObjectName("label_4");
        QFont font;
        font.setPointSize(14);
        font.setBold(false);
        label_4->setFont(font);
        label_4->setAlignment(Qt::AlignCenter);
        label_4->setMargin(10);

        gridLayout_4->addWidget(label_4, 0, 0, 1, 4);

        tableView = new QTableView(Products);
        tableView->setObjectName("tableView");
        QFont font1;
        font1.setPointSize(10);
        tableView->setFont(font1);

        gridLayout_4->addWidget(tableView, 3, 0, 1, 4);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName("gridLayout_3");
        addProduct = new QPushButton(Products);
        addProduct->setObjectName("addProduct");

        gridLayout_3->addWidget(addProduct, 1, 1, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName("gridLayout");
        label = new QLabel(Products);
        label->setObjectName("label");

        gridLayout->addWidget(label, 0, 0, 1, 1);

        name = new QLineEdit(Products);
        name->setObjectName("name");
        name->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(name, 0, 1, 1, 1);

        amount = new QLineEdit(Products);
        amount->setObjectName("amount");
        amount->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(amount, 1, 1, 1, 1);

        label_2 = new QLabel(Products);
        label_2->setObjectName("label_2");

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        price = new QLineEdit(Products);
        price->setObjectName("price");
        price->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(price, 2, 1, 1, 1);

        label_3 = new QLabel(Products);
        label_3->setObjectName("label_3");

        gridLayout->addWidget(label_3, 2, 0, 1, 1);


        gridLayout_3->addLayout(gridLayout, 0, 0, 2, 1);


        gridLayout_4->addLayout(gridLayout_3, 1, 0, 1, 4);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer, 4, 2, 1, 1);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName("gridLayout_2");
        cancel = new QPushButton(Products);
        cancel->setObjectName("cancel");

        gridLayout_2->addWidget(cancel, 0, 0, 1, 1);

        pushButton = new QPushButton(Products);
        pushButton->setObjectName("pushButton");

        gridLayout_2->addWidget(pushButton, 0, 1, 1, 1);

        pushButton_2 = new QPushButton(Products);
        pushButton_2->setObjectName("pushButton_2");

        gridLayout_2->addWidget(pushButton_2, 0, 2, 1, 1);


        gridLayout_4->addLayout(gridLayout_2, 4, 0, 1, 2);

        add_error = new QLabel(Products);
        add_error->setObjectName("add_error");
        add_error->setStyleSheet(QString::fromUtf8("color: #cf2323;\n"
"padding-bottom: 5px;\n"
"padding-left: 52px;"));

        gridLayout_4->addWidget(add_error, 2, 0, 1, 3);


        gridLayout_5->addLayout(gridLayout_4, 0, 0, 1, 1);


        retranslateUi(Products);

        QMetaObject::connectSlotsByName(Products);
    } // setupUi

    void retranslateUi(QDialog *Products)
    {
        Products->setWindowTitle(QCoreApplication::translate("Products", "\320\242\320\276\320\262\320\260\321\200\320\270", nullptr));
        label_4->setText(QCoreApplication::translate("Products", "\320\242\320\276\320\262\320\260\321\200\320\270", nullptr));
        addProduct->setText(QCoreApplication::translate("Products", "\320\224\320\276\320\264\320\260\321\202\320\270", nullptr));
        label->setText(QCoreApplication::translate("Products", "\320\235\320\260\320\267\320\262\320\260", nullptr));
        label_2->setText(QCoreApplication::translate("Products", "\320\232\321\226\320\273\321\214\320\272\321\226\321\201\321\202\321\214", nullptr));
        label_3->setText(QCoreApplication::translate("Products", "\320\246\321\226\320\275\320\260", nullptr));
        cancel->setText(QCoreApplication::translate("Products", "\320\235\320\260\320\267\320\260\320\264", nullptr));
        pushButton->setText(QCoreApplication::translate("Products", "\320\236\320\261\320\275\320\276\320\262\320\270\321\202\320\270", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Products", "\320\222\320\270\320\264\320\260\320\273\320\270\321\202\320\270", nullptr));
        add_error->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Products: public Ui_Products {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRODUCTS_H
