#include "restorepass.h"
#include "ui_restorepass.h"

RestorePass::RestorePass(QWidget* parent)
    : QDialog(parent)
    , ui(new Ui::RestorePass)
{
    ui->setupUi(this);

    setFixedSize(556, 496);
    sentCode = 0;
    flag = false;

    timeCount = 30;
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timerSlot()));
}

RestorePass::~RestorePass()
{
    delete ui;
}

void RestorePass::on_send_code_clicked()
{
    QString email = ui->email->text();

    SendEmail sm;
    Generator generator;
    QString sendTo = email;
    sentCode = generator.numGenerator(10000, 30000);
    QString send_answ = sm.sendEmail1(sentCode, sendTo);
    ui->send_code_err->setText(send_answ);

    if (send_answ == "Код відправлено") {
        ui->email_err->setText("");
        ui->send_code_err->setStyleSheet("color: green;");
        ui->send_code->setEnabled(false);
        ui->timer_text->setText("Повторити спробу через:");
        timer->start(1000);
    } else {
        ui->send_code_err->setStyleSheet("color: #cf2323;");
        ui->email_err->setText("Введіть email");
    }
}

void RestorePass::timerSlot()
{
    if (flag != true) {
        timeCount--;
        ui->timer_err->setText(QString::number(timeCount));
        if (timeCount == 0) {
            timer->stop();
            ui->timer_text->setText("");
            ui->timer_err->setText("");
            ui->send_code->setEnabled(true);
            timeCount = 30;
            ui->send_code_err->setText("");
        }
    } else {
        ui->send_code->setEnabled(false);
        ui->timer_text->setText("");
        ui->timer_err->setText("");
    }
}

void RestorePass::on_register_btn_clicked()
{
    QString pass = ui->pass->text();
    QString conf_pass = ui->conf_pass->text();
    QString email = ui->email->text();
    int reg_code = ui->code->text().toInt();

    flag = true;

    if (pass != "") {
        if (pass.size() >= 5) {
            if (pass.size() <= 20) {
                ui->pass_err->setText("");
            } else {
                ui->pass_err->setText("Максимальний ліміт \n20 символів");
                flag = false;
            }
        } else {
            ui->pass_err->setText("Мінімальний ліміт \n5 символів");
            flag = false;
        }
    } else {
        ui->pass_err->setText("Пусте значення");
        flag = false;
    }

    if (conf_pass != "") {
        if (pass == conf_pass) {
            ui->conf_pass_err->setText("");
        } else {
            ui->conf_pass_err->setText("Паролі не співпадають");
            flag = false;
        }
    } else {
        ui->conf_pass_err->setText("Пусте значення");
        flag = false;
    }

    if (email != "") {
        QRegularExpression pattern("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");

        if (pattern.match(email).hasMatch()) {
            ui->email_err->setText("");
        } else {
            ui->email_err->setText("Не коректний Email.\nПриклад: abc@email.com");
            flag = false;
        }
    } else {
        ui->email_err->setText("Пусте значення");
        flag = false;
    }

    QString reg_code_check_type = ui->code->text();
    bool var_type;
    int var1 = reg_code_check_type.toInt(&var_type);

    if (reg_code_check_type != "") {
        if (var_type) {
            if (reg_code != 0) {
                if (reg_code == sentCode) {
                    ui->code_err->setText("");
                } else {
                    ui->code_err->setText("Не правильний код");
                    flag = false;
                }
            } else {
                ui->code_err->setText("Ведіть код");
                flag = false;
            }
        } else {
            ui->code_err->setText("Ведіть числове \nзначення");
            flag = false;
        }
    } else {
        ui->code_err->setText("Пусте значення");
        flag = false;
    }

    if (flag) {
        ui->send_code_err->setText("");
        ui->send_code->setEnabled(false);

        QString pass_hash = QCryptographicHash::hash(pass.toUtf8(), QCryptographicHash::Md5);

        QSqlQuery q2 = QSqlQuery(db_control.db);
        QString str_q2 = QString("UPDATE accounts SET pass = '%1' WHERE email = '%2'").arg(pass_hash).arg(email);

        if (!q2.exec(str_q2)) {
            qDebug() << "Update Error TO DB!";
        } else {
            ui->result_reg->setStyleSheet("color: green;");
            ui->result_reg->setText("Пароль змінено!");
            ui->register_btn->setEnabled(false);
        }
    }
}

void RestorePass::on_cancel_btn_clicked()
{
    close();
}
