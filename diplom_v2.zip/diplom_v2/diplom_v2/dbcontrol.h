
#ifndef DBCONTROL_H
#define DBCONTROL_H

#include <QMessageBox>
#include <QtCore>
#include <QtNetwork>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlError>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlRecord>
#include <QtSql/QSqlTableModel>

//const QString HOST_NAME = "127.0.0.1";
//const int PORT_S = 3306;
//const QString DATA_BASE_NAME = "AccSys1";
//const QString USER_NAME = "root";
//const QString PASSWORD = "";

//vps-server reg
const QString HOST_NAME = "31.42.188.41";
const int PORT_S = 3305;
const QString DATA_BASE_NAME = "AccSys1";
const QString USER_NAME = "vitalii3";
const QString PASSWORD = "WmcXZC7H~Kr!Bs";

class DBControl {
public:
    DBControl();
    ~DBControl();

    QSqlDatabase db;

    QVector<QVector<QVariant>> results;

    void query1(QString queryReq);

    void printRes();

    void driverList();
};

#endif // DBCONTROL_H

//more flexible method
//QSqlQuery query = QSqlQuery(db.db);

//if (!query.exec("select * from reg_keys")) {
//    qDebug() << db.db.lastError().databaseText();
//    qDebug() << db.db.lastError().driverText();
//}
//while (query.next()) {
//    //        qDebug() << query.record();
//    qDebug() << query.value(0).toString() << query.value(1).toString() << query.value(2).toString();
//}

//convert data
//    qDebug() << (db.results[0][0]).toInt();
//    qDebug() << db.results[2][2].toFloat();

//query variant 2
//    db.query1("select * from reg_keys");
//    db.printRes();

//    db.query1("select user_key from reg_keys");
//    db.printRes();
