#ifndef RESTOREPASS_H
#define RESTOREPASS_H

#include "dbcontrol.h"
#include "generator.h"
#include "sendemail.h"
#include <QCryptographicHash>
#include <QDebug>
#include <QDialog>
#include <QRegularExpression>
#include <QTimer>
#include <QWidget>

namespace Ui {
class RestorePass;
}

class RestorePass : public QDialog {
    Q_OBJECT

public:
    explicit RestorePass(QWidget* parent = nullptr);
    ~RestorePass();

private slots:
    void on_send_code_clicked();
    void timerSlot();

    void on_register_btn_clicked();

    void on_cancel_btn_clicked();

private:
    Ui::RestorePass* ui;
    QTimer* timer;
    int timeCount;
    int sentCode;
    bool flag;
    DBControl db_control;
};

#endif // RESTOREPASS_H
