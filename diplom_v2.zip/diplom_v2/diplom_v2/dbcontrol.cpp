
#include "dbcontrol.h"
#include <QVariant>
#include <QVector>

DBControl::DBControl()
{

    db = QSqlDatabase::addDatabase("QMYSQL", "my_connection");
    db.setHostName(HOST_NAME);
    db.setPort(PORT_S);
    db.setDatabaseName(DATA_BASE_NAME);
    db.setUserName(USER_NAME);
    db.setPassword(PASSWORD);

    results = { {} };

    if (!db.open()) {
        qDebug() << db.lastError().text();
    } else {
        qDebug() << "Success connect to db:" << DATA_BASE_NAME;
    }
}

void DBControl::query1(QString queryReq)
{
    results.clear();
    QSqlQuery query = QSqlQuery(db);

    if (!query.exec(queryReq)) {
        qDebug() << db.lastError().databaseText() << "- db_control_err";
        qDebug() << db.lastError().driverText() << "- db_control_err";

        QMessageBox msgBox;
        msgBox.setText(QString("<font color='red'>'%1' <br>'%2'</font>").arg(db.lastError().databaseText()).arg(db.lastError().driverText()));
        msgBox.setWindowTitle("Попередження");
        msgBox.addButton("Ок", QMessageBox::AcceptRole);
        msgBox.exec();
    }

    while (query.next()) {
        QVector<QVariant> row;

        for (int i = 0; i < query.record().count(); ++i) {
            QVariant value = query.value(i);
            row.append(value);
        }

        results.append(row);
    }
}

void DBControl::printRes()
{
    qDebug() << "";
    QString str = "";

    for (int i = 0; i < results.size(); ++i) {
        for (int k = 0; k < (results[0]).size(); ++k) {

            str.append((results[i][k]).toString());
            str.append("\t");
        }

        qDebug().noquote() << str;
        str = "";
        qDebug() << "------------------------------------------";
    }
    qDebug() << "";
}

void DBControl::driverList()
{
    qDebug() << "Driver list" << QSqlDatabase::drivers();
}

DBControl::~DBControl()
{
    //    db.close();
}
