
#include "generator.h"

Generator::Generator()
{
    srand(time(NULL));
}

int Generator::numGenerator(int from, int to)
{
    if (to >= 31000) {
        qDebug() << "Maximum number limit exceeded!";
        return -9999;
    }

    int param_to = to + 1 - from;

    return rand() % param_to + from;
}
