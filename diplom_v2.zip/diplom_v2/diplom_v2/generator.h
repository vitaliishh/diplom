
#ifndef GENERATOR_H
#define GENERATOR_H

#include <QDebug>
#include <ctime>
#include <iostream>

class Generator {
public:
    Generator();

    int numGenerator(int from, int to);
};

#endif // GENERATOR_H
