#include "editaccount.h"
#include "ui_editaccount.h"

EditAccount::EditAccount(int id, int mode, QWidget* parent)
    : QDialog(parent)
    , ui(new Ui::EditAccount)
{
    ui->setupUi(this);
    this->id = id;
    this->mode = mode;

    if (mode == 0) {
        ui->label_6->setText(QString("№%1").arg(QString::number(id)));

        table_model = new QSqlRelationalTableModel(this, db_control.db);
        table_model->setTable("account");
        table_model->setRelation(table_model->fieldIndex("buyer"), QSqlRelation("companies", "id", "company_name"));

        table_model->select();
        //        table_model->query().lastQuery();
        QString filter = QString("account.id = %1").arg(id);
        table_model->setFilter(filter);

        table_model->setHeaderData(2, Qt::Horizontal, "Покупець", Qt::DisplayRole);
        table_model->setHeaderData(8, Qt::Horizontal, "Постачальник", Qt::DisplayRole);
        table_model->setHeaderData(9, Qt::Horizontal, "Адрес постачальника", Qt::DisplayRole);
        table_model->setHeaderData(13, Qt::Horizontal, "Телефон постачальника", Qt::DisplayRole);
        table_model->setHeaderData(10, Qt::Horizontal, "ЄДРПОУ", Qt::DisplayRole);
        table_model->setHeaderData(11, Qt::Horizontal, "Рахунок отримувача", Qt::DisplayRole);
        table_model->setHeaderData(16, Qt::Horizontal, "Дата отримання", Qt::DisplayRole);
        table_model->setHeaderData(12, Qt::Horizontal, "Надавач платіжних послуг", Qt::DisplayRole);
        table_model->setHeaderData(19, Qt::Horizontal, "Виписав(ла)", Qt::DisplayRole);

        ui->tableView->setModel(table_model);

        ui->tableView->setColumnHidden(0, true);
        ui->tableView->setColumnHidden(1, true);
        ui->tableView->setColumnHidden(3, true);
        ui->tableView->setColumnHidden(4, true);
        ui->tableView->setColumnHidden(5, true);
        ui->tableView->setColumnHidden(6, true);
        ui->tableView->setColumnHidden(7, true);
        ui->tableView->setColumnHidden(14, true);
        ui->tableView->setColumnHidden(15, true);
        ui->tableView->setColumnHidden(17, true);
        ui->tableView->setColumnHidden(18, true);
        ui->tableView->setColumnHidden(20, true);
        ui->tableView->setColumnHidden(21, true);
        ui->tableView->setColumnHidden(22, true);
        ui->tableView->setColumnHidden(23, true);
        ui->tableView->setColumnHidden(24, true);
        ui->tableView->setColumnHidden(25, true);
        ui->tableView->setColumnHidden(26, true);
        ui->tableView->setColumnHidden(27, true);
        ui->tableView->setColumnHidden(28, true);
        ui->tableView->setColumnHidden(29, true);
        ui->tableView->setColumnHidden(30, true);

    } else if (mode == 1) {
        ui->label_4->setText("Довіреність");
        ui->label_6->setText(QString("№%1").arg(QString::number(id)));

        table_model = new QSqlRelationalTableModel(this, db_control.db);
        table_model->setTable("account");
        table_model->select();

        QString filter = QString("account.id = %1").arg(id);
        table_model->setFilter(filter);

        table_model->setHeaderData(21, Qt::Horizontal, "Дата видачі", Qt::DisplayRole);
        table_model->setHeaderData(22, Qt::Horizontal, "Дійсна до", Qt::DisplayRole);
        table_model->setHeaderData(23, Qt::Horizontal, "Видано", Qt::DisplayRole);
        table_model->setHeaderData(24, Qt::Horizontal, "Паспортні дані особи, якій видано", Qt::DisplayRole);

        ui->tableView->setModel(table_model);

        ui->tableView->setColumnHidden(0, true);
        ui->tableView->setColumnHidden(1, true);
        ui->tableView->setColumnHidden(2, true);
        ui->tableView->setColumnHidden(3, true);
        ui->tableView->setColumnHidden(4, true);
        ui->tableView->setColumnHidden(5, true);
        ui->tableView->setColumnHidden(6, true);
        ui->tableView->setColumnHidden(7, true);
        ui->tableView->setColumnHidden(8, true);
        ui->tableView->setColumnHidden(9, true);
        ui->tableView->setColumnHidden(10, true);
        ui->tableView->setColumnHidden(11, true);
        ui->tableView->setColumnHidden(12, true);
        ui->tableView->setColumnHidden(13, true);
        ui->tableView->setColumnHidden(14, true);
        ui->tableView->setColumnHidden(15, true);
        ui->tableView->setColumnHidden(16, true);
        ui->tableView->setColumnHidden(17, true);
        ui->tableView->setColumnHidden(18, true);
        ui->tableView->setColumnHidden(19, true);
        ui->tableView->setColumnHidden(20, true);
        ui->tableView->setColumnHidden(25, true);
        ui->tableView->setColumnHidden(26, true);
        ui->tableView->setColumnHidden(27, true);
        ui->tableView->setColumnHidden(28, true);
        ui->tableView->setColumnHidden(29, true);
        ui->tableView->setColumnHidden(30, true);

    } else if (mode == 2) {
        ui->label_4->setText("Видаткова накладна");
        ui->label_6->setText(QString("№%1").arg(QString::number(id)));

        table_model = new QSqlRelationalTableModel(this, db_control.db);
        table_model->setTable("account");
        table_model->select();

        QString filter = QString("account.id = %1").arg(id);
        table_model->setFilter(filter);

        table_model->setHeaderData(29, Qt::Horizontal, "Місце складання", Qt::DisplayRole);
        table_model->setHeaderData(30, Qt::Horizontal, "Дата видання", Qt::DisplayRole);

        ui->tableView->setModel(table_model);

        for (int i = 0; i < 29; ++i) {
            ui->tableView->setColumnHidden(i, true);
        }
    } else if (mode == 3) {
        ui->label_4->setText("Товар");
        ui->label_6->setText(QString("№%1").arg(QString::number(id)));

        table_model = new QSqlRelationalTableModel(this, db_control.db);
        table_model->setTable("products");
        table_model->select();

        QString filter = QString("id = %1").arg(id);
        table_model->setFilter(filter);

        table_model->setHeaderData(6, Qt::Horizontal, "Кількість", Qt::DisplayRole);

        ui->tableView->setModel(table_model);

        ui->tableView->setColumnHidden(0, true);
        ui->tableView->setColumnHidden(1, true);
        ui->tableView->setColumnHidden(2, true);
        ui->tableView->setColumnHidden(3, true);
        ui->tableView->setColumnHidden(4, true);
        ui->tableView->setColumnHidden(5, true);
    } else if (mode == 4) {

        ui->label_4->setText("Платіжна інструкція");
        ui->label_6->setText(QString("№%1").arg(QString::number(id)));

        table_model = new QSqlRelationalTableModel(this, db_control.db);
        table_model->setTable("account");
        table_model->select();

        QString filter = QString("account.id = %1").arg(id);
        table_model->setFilter(filter);

        table_model->setHeaderData(8, Qt::Horizontal, "Отримувач", Qt::DisplayRole);
        table_model->setHeaderData(10, Qt::Horizontal, "Код отримувача", Qt::DisplayRole);
        table_model->setHeaderData(11, Qt::Horizontal, "Рахунок отримувача", Qt::DisplayRole);
        table_model->setHeaderData(12, Qt::Horizontal, "Надавач платіжних послуг отримувача", Qt::DisplayRole);
        table_model->setHeaderData(17, Qt::Horizontal, "Дата прийняття до виконання", Qt::DisplayRole);
        table_model->setHeaderData(18, Qt::Horizontal, "Дата виконання", Qt::DisplayRole);

        ui->tableView->setModel(table_model);

        for (int i = 0; i < 31; ++i) {
            if (i != 8 && i != 10 && i != 11 && i != 12 && i != 17 && i != 18) {
                ui->tableView->setColumnHidden(i, true);
            }
        }
    }

    ui->tableView->resizeColumnsToContents();

    for (int col = 0; col < table_model->columnCount(); ++col) {
        ui->tableView->setColumnWidth(col, std::min(ui->tableView->columnWidth(col), 200));
    }
}

EditAccount::~EditAccount()
{
    emit returnedToMainWindow();
    delete ui;
}

void EditAccount::on_pushButton_clicked()
{
    close();
}
