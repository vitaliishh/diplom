#include "registration.h"
#include "ui_registration.h"

Registration::Registration(QWidget* parent)
    : QDialog(parent)
    , ui(new Ui::Registration)
{
    ui->setupUi(this);

    //    setWindowFlag(Qt::WindowStaysOnTopHint, true);
    setFixedSize(556, 581);
    sentCode = 0;
    flag = false;

    timeCount = 30;
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timerSlot()));
}

Registration::~Registration()
{
    db_control.db.close();
    QSqlDatabase::removeDatabase("my_connection");
    qDebug() << "dell reg win";
    delete ui;
}

void Registration::on_send_code_clicked()
{
    QString email = ui->email->text();
    db_control.query1(QString("select id from accounts where email='%1'").arg(email));

    if (db_control.results.size() != 0) {
        ui->register_btn->setEnabled(true);
        ui->result_reg->setStyleSheet("color: #cf2323;");
        ui->result_reg->setText("На цей Email вже створено акаунт!");
    } else {
        ui->result_reg->setText("");
        SendEmail sm;
        Generator generator;
        QString sendTo = email;
        sentCode = generator.numGenerator(10000, 30000);
        QString send_answ = sm.sendEmail1(sentCode, sendTo);
        ui->send_code_err->setText(send_answ);

        if (send_answ == "Код відправлено") {
            ui->email_err->setText("");
            ui->send_code_err->setStyleSheet("color: green;");
            ui->send_code->setEnabled(false);
            ui->timer_text->setText("Повторити спробу через:");
            timer->start(1000);
        } else {
            ui->send_code_err->setStyleSheet("color: #cf2323;");
            ui->email_err->setText("Введіть коректний \nemail");
        }
    }
}

void Registration::timerSlot()
{

    if (flag != true) {
        timeCount--;
        ui->timer_err->setText(QString::number(timeCount));
        if (timeCount == 0) {
            timer->stop();
            ui->timer_text->setText("");
            ui->timer_err->setText("");
            ui->send_code->setEnabled(true);
            timeCount = 30;
            ui->send_code_err->setText("");
        }
    } else {
        ui->send_code->setEnabled(false);
        ui->timer_text->setText("");
        ui->timer_err->setText("");
    }
}

void Registration::on_register_btn_clicked()
{
    QString nick = ui->nick->text();
    QString pass = ui->pass->text();
    QString conf_pass = ui->conf_pass->text();
    QString email = ui->email->text();
    int reg_code = ui->code->text().toInt();

    flag = true;

    if (nick != "") {
        if (nick.size() >= 5) {
            if (nick.size() <= 20) {
                db_control.query1(QString("select id from accounts where name='%1'").arg(nick));
                if (db_control.results.size() == 0) {
                    ui->nick_err->setText("");
                } else {
                    ui->nick_err->setText("Виберіть інший нік");
                    flag = false;
                }

            } else {
                ui->nick_err->setText("Максимальний ліміт \n20 символів");
                flag = false;
            }
        } else {
            ui->nick_err->setText("Мінімальний ліміт \n5 символів");
            flag = false;
        }
    } else {
        ui->nick_err->setText("Пусте значення");
        flag = false;
    }

    if (pass != "") {
        if (pass.size() >= 5) {
            if (pass.size() <= 20) {
                ui->pass_err->setText("");
            } else {
                ui->pass_err->setText("Максимальний ліміт \n20 символів");
                flag = false;
            }
        } else {
            ui->pass_err->setText("Мінімальний ліміт \n5 символів");
            flag = false;
        }
    } else {
        ui->pass_err->setText("Пусте значення");
        flag = false;
    }

    if (conf_pass != "") {
        if (pass == conf_pass) {
            ui->conf_pass_err->setText("");
        } else {
            ui->conf_pass_err->setText("Паролі не співпадають");
            flag = false;
        }
    } else {
        ui->conf_pass_err->setText("Пусте значення");
        flag = false;
    }

    if (email != "") {
        QRegularExpression pattern("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");

        if (pattern.match(email).hasMatch()) {
            ui->email_err->setText("");
        } else {
            ui->email_err->setText("Не коректний Email.\nПриклад: abc@email.com");
            flag = false;
        }
    } else {
        ui->email_err->setText("Пусте значення");
        flag = false;
    }

    QString reg_code_check_type = ui->code->text();
    bool var_type;
    int var1 = reg_code_check_type.toInt(&var_type);

    if (reg_code_check_type != "") {
        if (var_type) {
            if (reg_code != 0) {
                if (reg_code == sentCode) {
                    ui->code_err->setText("");
                } else {
                    ui->code_err->setText("Не правильний код");
                    flag = false;
                }
            } else {
                ui->code_err->setText("Ведіть код");
                flag = false;
            }
        } else {
            ui->code_err->setText("Ведіть числове \nзначення");
            flag = false;
        }
    } else {
        ui->code_err->setText("Пусте значення");
        flag = false;
    }

    if (flag) {

        db_control.query1(QString("select id from accounts where email='%1'").arg(email));

        if (db_control.results.size() == 0) {
            ui->send_code_err->setText("");
            ui->send_code->setEnabled(false);

            QString pass_hash = QCryptographicHash::hash(pass.toUtf8(), QCryptographicHash::Md5);

            QSqlQuery q2 = QSqlQuery(db_control.db);
            QString str_q2 = QString("INSERT INTO accounts (name, pass, email) values('%1', '%2', '%3')").arg(nick).arg(pass_hash).arg(email);

            if (!q2.exec(str_q2)) {
                qDebug() << "Insert Error TO DB!";
            } else {
                ui->result_reg->setStyleSheet("color: green;");
                ui->result_reg->setText("Реєстрація пройшла упішно!");
                ui->register_btn->setEnabled(false);
            }
        }
    }
}

void Registration::on_cancel_btn_clicked()
{
    close();
}
