#ifndef EDITACCOUNT_H
#define EDITACCOUNT_H

#include "dbcontrol.h"
#include <QDialog>
#include <QPushButton>
#include <QSqlQuery>
#include <QSqlRelationalDelegate>
#include <QSqlRelationalTableModel>
#include <QSqlTableModel>

namespace Ui {
class EditAccount;
}

class EditAccount : public QDialog {
    Q_OBJECT

public:
    explicit EditAccount(int id, int mode = 0, QWidget* parent = nullptr);
    ~EditAccount();

signals:
    void returnedToMainWindow();

private slots:
    void on_pushButton_clicked();

private:
    Ui::EditAccount* ui;
    int id;
    DBControl db_control;
    QSqlRelationalTableModel* table_model;
    int mode;
};

#endif // EDITACCOUNT_H
