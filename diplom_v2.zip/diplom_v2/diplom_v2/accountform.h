#ifndef ACCOUNTFORM_H
#define ACCOUNTFORM_H

#include "dbcontrol.h"
#include <QCheckBox>
#include <QDialog>
#include <QPushButton>
#include <QSqlQuery>
#include <QSqlRelationalDelegate>
#include <QSqlRelationalTableModel>
#include <QSqlTableModel>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVector>

namespace Ui {
class AccountForm;
}

class AccountForm : public QDialog {
    Q_OBJECT

public:
    explicit AccountForm(int id, QWidget* parent = nullptr);
    ~AccountForm();

signals:
    void returnedToMainWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::AccountForm* ui;
    DBControl db_control;
    int id;
};

#endif // ACCOUNTFORM_H
