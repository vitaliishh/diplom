
#ifndef SENDEMAIL_H
#define SENDEMAIL_H

#include "SmtpMime"

const QString MY_ACCOUNT = "vitalikoleg2003@gmail.com";
const QString MY_PASS = "katydavlpbldqgvl";
const QString CLIENT = "smtp.gmail.com";
const int PORT = 465;

class SendEmail {
public:
    SendEmail();

    QString sendEmail1(int code, QString sendTo);
};

#endif // SENDEMAIL_H
