
#include "login.h"

#include <QApplication>
#include <QAxObject>
#include <QMessageBox>

int main(int argc, char* argv[])
{
    QApplication a(argc, argv);

    Login* login = new Login();
    login->setAttribute(Qt::WA_DeleteOnClose);
    login->setFixedSize(521, 490);

    login->show();

    QNetworkAccessManager manager;
    QNetworkRequest request(QUrl("http://www.google.com"));
    QNetworkReply* reply = manager.get(request);

    QObject::connect(reply, &QNetworkReply::finished, [&]() {
        if (reply->error() == QNetworkReply::NoError) {

        } else {

            QMessageBox msgBox;
            msgBox.setText("<font color='red'>Відсутнє інтернет підключення !</font>");
            msgBox.setWindowTitle("Попередження");
            msgBox.addButton("Ок", QMessageBox::AcceptRole);
            msgBox.exec();

            a.quit();
        }
        reply->deleteLater();
    });

    return a.exec();
}
