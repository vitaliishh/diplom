#include "products.h"
#include "ui_products.h"

Products::Products(int id, int product_id, int mode, QWidget* parent)
    : QDialog(parent)
    , ui(new Ui::Products)
{
    ui->setupUi(this);

    this->id = id;
    this->product_id = product_id;
    this->mode = mode;

    if (mode == 0) {
        table_model = new QSqlTableModel(this, db_control.db);
        table_model->setTable("products");
        QString filter = QString("product_id = %1").arg(product_id);
        table_model->setFilter(filter);
        table_model->select();

        table_model->setHeaderData(2, Qt::Horizontal, "Товари", Qt::DisplayRole);
        table_model->setHeaderData(3, Qt::Horizontal, "Кількість", Qt::DisplayRole);
        table_model->setHeaderData(4, Qt::Horizontal, "Ціна", Qt::DisplayRole);

        ui->tableView->setModel(table_model);
        ui->tableView->setColumnHidden(0, true);
        ui->tableView->setColumnHidden(1, true);
        ui->tableView->setColumnHidden(5, true);
        ui->tableView->setColumnHidden(6, true);
    } else if (mode == 1) {

        table_model = new QSqlTableModel(this, db_control.db);
        table_model->setTable("products");
        QString filter = QString("product_id = %1").arg(product_id);
        table_model->setFilter(filter);
        table_model->select();

        table_model->setHeaderData(2, Qt::Horizontal, "Товари", Qt::DisplayRole);
        table_model->setHeaderData(3, Qt::Horizontal, "Кількість", Qt::DisplayRole);
        table_model->setHeaderData(4, Qt::Horizontal, "Ціна", Qt::DisplayRole);

        ui->tableView->setModel(table_model);
        ui->tableView->setColumnHidden(0, true);
        ui->tableView->setColumnHidden(1, true);
        ui->tableView->setColumnHidden(5, true);
        ui->tableView->setColumnHidden(6, true);

        ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        ui->name->setVisible(false);
        ui->amount->setVisible(false);
        ui->price->setVisible(false);
        ui->label->setVisible(false);
        ui->label_2->setVisible(false);
        ui->label_3->setVisible(false);
        ui->addProduct->setVisible(false);
        ui->add_error->setVisible(false);
        ui->pushButton_2->setVisible(false);
    } else if (mode == 2) {
        table_model = new QSqlTableModel(this, db_control.db);
        table_model->setTable("product_na_items");
        QString filter = QString("id_na = %1").arg(product_id);
        table_model->setFilter(filter);
        table_model->select();

        table_model->setHeaderData(3, Qt::Horizontal, "Найменування", Qt::DisplayRole);
        table_model->setHeaderData(4, Qt::Horizontal, "Кількість", Qt::DisplayRole);
        table_model->setHeaderData(5, Qt::Horizontal, "Ціна", Qt::DisplayRole);
        table_model->setHeaderData(6, Qt::Horizontal, "Сума", Qt::DisplayRole);

        ui->tableView->setModel(table_model);
        ui->tableView->setColumnHidden(0, true);
        ui->tableView->setColumnHidden(1, true);
        ui->tableView->setColumnHidden(2, true);

        ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        ui->name->setVisible(false);
        ui->amount->setVisible(false);
        ui->price->setVisible(false);
        ui->label->setVisible(false);
        ui->label_2->setVisible(false);
        ui->label_3->setVisible(false);
        ui->addProduct->setVisible(false);
        ui->add_error->setVisible(false);
        ui->pushButton_2->setVisible(false);
    }

    ui->tableView->resizeColumnsToContents();

    for (int col = 0; col < table_model->columnCount(); ++col) {
        ui->tableView->setColumnWidth(col, std::min(ui->tableView->columnWidth(col), 200));
    }
}

Products::~Products()
{
    emit returnedToMainWindow();
    delete ui;
}

void Products::on_cancel_clicked()
{
    close();
}

void Products::on_addProduct_clicked()
{
    QString name = ui->name->text();
    QString amount = ui->amount->text();
    QString price = ui->price->text();

    if (name != "") {

        if (amount != "") {
            bool var_type;
            int var1 = amount.toInt(&var_type);

            if (var_type) {

                if (price != "") {
                    bool var_type2;
                    int var2 = price.toInt(&var_type2);

                    if (var_type2) {
                        ui->add_error->setText("");
                        QSqlQuery s1 = QSqlQuery(db_control.db);

                        QString str_q = QString("INSERT INTO products (product_id, product_name, amount, price, account_id, edit_amount) values('%1', '%2', '%3', '%4', '%5', '%6')").arg(product_id).arg(name).arg(amount).arg(price).arg(id).arg(amount);

                        if (!s1.exec(str_q)) {
                            qDebug() << "Insert Error occurred:" << s1.lastError().text();
                        } else {
                            table_model->select();
                            ui->add_error->setStyleSheet("color: green; padding-bottom: 5px; padding-left: 52px;");
                            ui->add_error->setText("Товар додано");
                        }

                    } else {
                        ui->add_error->setText("Не коректне значення ціни");
                    }
                } else {
                    ui->add_error->setText("Пусте значення ціни");
                }
            } else {
                ui->add_error->setText("Не коректне значення кількості");
            }
        } else {
            ui->add_error->setText("Пусте значення кількості");
        }
    } else {
        ui->add_error->setText("Пусте значення назви");
    }
}

void Products::on_pushButton_clicked()
{
    table_model->select();
}

void Products::on_pushButton_2_clicked()
{
    int selectedRow = ui->tableView->currentIndex().row();

    if (selectedRow >= 0) {
        table_model->removeRow(selectedRow);
    }
}
