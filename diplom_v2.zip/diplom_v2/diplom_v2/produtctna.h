#ifndef PRODUTCTNA_H
#define PRODUTCTNA_H

#include "dbcontrol.h"
#include <QDate>
#include <QDateEdit>
#include <QDialog>
#include <QMessageBox>
#include <QPushButton>
#include <QSqlQuery>
#include <QTableWidgetItem>
#include <QVBoxLayout>

namespace Ui {
class ProdutctNa;
}

class ProdutctNa : public QDialog {
    Q_OBJECT

public:
    explicit ProdutctNa(int user_id, QWidget* parent = nullptr);
    ~ProdutctNa();

signals:
    void returnedToMainWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::ProdutctNa* ui;

    int user_id;
    DBControl db_control;
};

#endif // PRODUTCTNA_H
