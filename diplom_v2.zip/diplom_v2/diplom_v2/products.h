#ifndef PRODUCTS_H
#define PRODUCTS_H

#include "dbcontrol.h"
#include <QCheckBox>
#include <QDialog>
#include <QPushButton>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVector>

namespace Ui {
class Products;
}

class Products : public QDialog {
    Q_OBJECT

public:
    explicit Products(int id, int product_id, int mode = 0, QWidget* parent = nullptr);
    ~Products();

signals:
    void returnedToMainWindow();

private slots:
    void on_cancel_clicked();

    void on_addProduct_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    DBControl db_control;
    Ui::Products* ui;
    QSqlTableModel* table_model;
    int id;
    int product_id;
    int mode;
};

#endif // PRODUCTS_H
