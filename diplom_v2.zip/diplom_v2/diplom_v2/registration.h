#ifndef REGISTRATION_H
#define REGISTRATION_H

#include "dbcontrol.h"
#include "generator.h"
#include "sendemail.h"
#include <QCryptographicHash>
#include <QDebug>
#include <QDialog>
#include <QRegularExpression>
#include <QTimer>
#include <QWidget>

namespace Ui {
class Registration;
}

class Registration : public QDialog {
    Q_OBJECT

public:
    explicit Registration(QWidget* parent = nullptr);
    ~Registration();

private slots:
    void on_send_code_clicked();
    void timerSlot();

    void on_register_btn_clicked();

    void on_cancel_btn_clicked();

private:
    Ui::Registration* ui;
    QTimer* timer;
    int timeCount;
    int sentCode;
    bool flag;
    DBControl db_control;
};

#endif // REGISTRATION_H
