#include "infwindow.h"
#include "ui_infwindow.h"

InfWindow::InfWindow(int id, QString nick, QString email, QString pass, QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui::InfWindow)
{
    ui->setupUi(this);

    this->id = id;
    this->nick = nick;
    this->email = email;
    this->pass = pass;

    fillTableWidget();
    fillPayInstruction();
    fillAttorneyPower();
    fillSalesInvoice();
    fillWarehouse();
    fillEditOrganization();
    fillProductNa();
}

InfWindow::~InfWindow()
{

    qDebug() << "dell Inf Winddow";
    delete ui;
}

void InfWindow::on_pushButton_6_clicked()
{
    QString val = ui->filterWarehouse->currentText();

    if (val == "По назві товару") {
        fillWarehouse(1);
    } else if (val == "По номеру товару") {
        fillWarehouse(2);
    } else if (val == "По номеру накладної") {
        fillWarehouse(3);
    }
}

void InfWindow::on_pushButton_8_clicked()
{
    fillWarehouse(4);
}

void InfWindow::fillWarehouse(int mode)
{

    QString val1;

    if (mode == 0) {
        db_control.query1(QString("SELECT p.product_name, p.edit_amount, p.price, a.na_date, a.id, p.id, p.amount FROM account as a, products as p WHERE a.id = p.product_id and a.account_id = p.account_id and a.visa = 1 and a.pi_visa = 1 and a.v_visa_of_issued = 1 and a.v_visa_director = 1 and a.na_buyer_visa = 1 and a.na_supplier_visa = 1 and a.account_id='%1' ORDER BY p.id DESC;").arg(id));
    } else if (mode == 1) {
        val1 = ui->search_by_name->text();
        db_control.query1(QString("SELECT p.product_name, p.edit_amount, p.price, a.na_date, a.id, p.id, p.amount FROM account as a, products as p WHERE a.id = p.product_id and a.account_id = p.account_id and a.visa = 1 and a.pi_visa = 1 and a.v_visa_of_issued = 1 and a.v_visa_director = 1 and a.na_buyer_visa = 1 and a.na_supplier_visa = 1 and a.account_id='%1' and p.product_name LIKE '%%%2%' ORDER BY p.id DESC;").arg(id).arg(val1));
    } else if (mode == 2) {
        val1 = ui->search_by_name->text();
        db_control.query1(QString("SELECT p.product_name, p.edit_amount, p.price, a.na_date, a.id, p.id, p.amount FROM account as a, products as p WHERE a.id = p.product_id and a.account_id = p.account_id and a.visa = 1 and a.pi_visa = 1 and a.v_visa_of_issued = 1 and a.v_visa_director = 1 and a.na_buyer_visa = 1 and a.na_supplier_visa = 1 and a.account_id='%1' and p.id = '%2' ORDER BY p.id DESC;").arg(id).arg(val1));
    } else if (mode == 3) {
        val1 = ui->search_by_name->text();
        db_control.query1(QString("SELECT p.product_name, p.edit_amount, p.price, a.na_date, a.id, p.id, p.amount FROM account as a, products as p WHERE a.id = p.product_id and a.account_id = p.account_id and a.visa = 1 and a.pi_visa = 1 and a.v_visa_of_issued = 1 and a.v_visa_director = 1 and a.na_buyer_visa = 1 and a.na_supplier_visa = 1 and a.account_id='%1' and p.product_id = '%2' ORDER BY p.id DESC;").arg(id).arg(val1));
    } else if (mode == 4) {

        ui->dateFilter1->setDisplayFormat("yyyy-MM-dd");
        ui->dateFilter2->setDisplayFormat("yyyy-MM-dd");

        QString date_from = ui->dateFilter1->text();
        QString date_to = ui->dateFilter2->text();
        qDebug() << date_from << date_to;
        val1 = ui->search_by_name->text();
        db_control.query1(QString("SELECT p.product_name, p.edit_amount, p.price, a.na_date, a.id, p.id, p.amount FROM account as a, products as p WHERE a.id = p.product_id and a.account_id = p.account_id and a.visa = 1 and a.pi_visa = 1 and a.v_visa_of_issued = 1 and a.v_visa_director = 1 and a.na_buyer_visa = 1 and a.na_supplier_visa = 1 and a.account_id='%1' and a.na_date >= '%2' and a.na_date <= '%3' ORDER BY p.id DESC;").arg(id).arg(date_from).arg(date_to));
    }

    QVector<QVector<QVariant>> resArr = db_control.results;

    ui->warehouse_table->setRowCount(resArr.size());
    ui->warehouse_table->setColumnCount(8);

    QStringList headers;
    headers << "№ товару"
            << "Найменування"
            << "Залишок"
            << "Видано"
            << "Ціна"
            << "Сума"
            << "Дата"
            << "№ накладної";

    ui->warehouse_table->setHorizontalHeaderLabels(headers);

    ui->warehouse_table->setSortingEnabled(true);

    for (int i = 0; i < ui->warehouse_table->rowCount(); ++i) {

        QTableWidgetItem* item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, resArr[i][5].toInt());
        ui->warehouse_table->setItem(i, 0, item);

        item = new QTableWidgetItem(resArr[i][0].toString());
        ui->warehouse_table->setItem(i, 1, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, resArr[i][1].toInt());
        ui->warehouse_table->setItem(i, 2, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, resArr[i][6].toInt() - resArr[i][1].toInt());
        ui->warehouse_table->setItem(i, 3, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, resArr[i][2].toInt());
        ui->warehouse_table->setItem(i, 4, item);

        int sum = resArr[i][1].toInt() * resArr[i][2].toInt();

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, sum);
        ui->warehouse_table->setItem(i, 5, item);

        item = new QTableWidgetItem(resArr[i][3].toString());
        ui->warehouse_table->setItem(i, 6, item);

        item = new QTableWidgetItem();
        item->setData(Qt::DisplayRole, resArr[i][4].toInt());
        ui->warehouse_table->setItem(i, 7, item);
    }

    ui->warehouse_table->resizeColumnsToContents();

    for (int col = 0; col < ui->warehouse_table->columnCount(); ++col) {
        ui->warehouse_table->setColumnWidth(col, std::min(ui->warehouse_table->columnWidth(col), 200));
    }
}

void InfWindow::fillSalesInvoice()
{
    db_control.query1(QString("SELECT a.id, a.supplier, a.supplier_account, a.supplier_bank, a.supplier_address, a.supplier_tel, a.edrpou, c.company_name, c.address, c.tel, a.na_create_place, a.na_date ,a.na_buyer_visa, a.na_supplier_visa FROM account as a, companies as c WHERE a.buyer = c.id and a.visa = 1 and a.pi_visa = 1 and a.v_visa_of_issued = 1 and a.v_visa_director = 1 and a.account_id='%1' ORDER BY a.id DESC;").arg(id));
    QVector<QVector<QVariant>> resArr = db_control.results;

    ui->sales_invoice->setRowCount(resArr.size());
    ui->sales_invoice->setColumnCount(16);

    QStringList headers;
    headers << "№ рахунку"
            << "Постачальник"
            << "Рахунок постачальника"
            << "Рахунок у банку"
            << "Адреса постачальника"
            << "Телефон постачальника"
            << "ЄДРПОУ постачальника"
            << "Покупець"
            << "Адреса покупця"
            << "Телефон покупця"
            << "Місце складання"
            << "Дата видання"
            << "Підпис постачальника"
            << "Підпис особи, що отримала"
            << "Товари"
            << "Редагувати";

    ui->sales_invoice->setHorizontalHeaderLabels(headers);

    for (int i = 0; i < ui->sales_invoice->rowCount(); ++i) {

        QTableWidgetItem* item = new QTableWidgetItem(resArr[i][0].toString());
        ui->sales_invoice->setItem(i, 0, item);

        item = new QTableWidgetItem(resArr[i][1].toString());
        ui->sales_invoice->setItem(i, 1, item);

        item = new QTableWidgetItem(resArr[i][2].toString());
        ui->sales_invoice->setItem(i, 2, item);

        item = new QTableWidgetItem(resArr[i][3].toString());
        ui->sales_invoice->setItem(i, 3, item);

        item = new QTableWidgetItem(resArr[i][4].toString());
        ui->sales_invoice->setItem(i, 4, item);

        item = new QTableWidgetItem(resArr[i][5].toString());
        ui->sales_invoice->setItem(i, 5, item);

        item = new QTableWidgetItem(resArr[i][6].toString());
        ui->sales_invoice->setItem(i, 6, item);

        item = new QTableWidgetItem(resArr[i][7].toString());
        ui->sales_invoice->setItem(i, 7, item);

        item = new QTableWidgetItem(resArr[i][8].toString());
        ui->sales_invoice->setItem(i, 8, item);

        item = new QTableWidgetItem(resArr[i][9].toString());
        ui->sales_invoice->setItem(i, 9, item);

        item = new QTableWidgetItem(resArr[i][10].toString());
        ui->sales_invoice->setItem(i, 10, item);

        item = new QTableWidgetItem(resArr[i][11].toString());
        ui->sales_invoice->setItem(i, 11, item);

        //check box
        QCheckBox* checkBox = new QCheckBox("");
        if (resArr[i][12].toInt() == 1) {
            checkBox->setChecked(true);
        } else {
            checkBox->setChecked(false);
        }

        connect(checkBox, &QCheckBox::stateChanged, [=](int state) {
            if (state == Qt::Checked) {

                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET na_buyer_visa = '%1' WHERE id = '%2'").arg(1).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            } else {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET na_buyer_visa = '%1' WHERE id = '%2'").arg(0).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            }
        });

        QWidget* widget = new QWidget();
        QVBoxLayout* layout = new QVBoxLayout(widget);
        layout->addWidget(checkBox);
        layout->setAlignment(Qt::AlignCenter);
        layout->setContentsMargins(1, 1, 1, 1);
        widget->setLayout(layout);

        ui->sales_invoice->setCellWidget(i, 12, widget);

        QCheckBox* checkBox2 = new QCheckBox("");
        if (resArr[i][13].toInt() == 1) {
            checkBox2->setChecked(true);
        } else {
            checkBox2->setChecked(false);
        }

        connect(checkBox2, &QCheckBox::stateChanged, [=](int state) {
            if (state == Qt::Checked) {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET na_supplier_visa = '%1' WHERE id = '%2'").arg(1).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            } else {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET na_supplier_visa = '%1' WHERE id = '%2'").arg(0).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            }
        });

        QWidget* widget2 = new QWidget();
        QVBoxLayout* layout2 = new QVBoxLayout(widget2);
        layout2->addWidget(checkBox2);
        layout2->setAlignment(Qt::AlignCenter);
        layout2->setContentsMargins(1, 1, 1, 1);
        widget2->setLayout(layout2);

        ui->sales_invoice->setCellWidget(i, 13, widget2);
        //check box end

        //button open products
        QPushButton* btn3 = new QPushButton();
        QIcon icon3(":/img/res/btn/free-icon-expand-8975040.png");
        btn3->setIcon(icon3);
        btn3->setFixedWidth(25);
        btn3->setFixedHeight(25);

        int value3 = resArr[i][0].toInt();
        connect(btn3, &QPushButton::clicked, this, [this, value3]() {
            Products products(id, value3, 1);
            connect(&products, &Products::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
            products.exec();
        });

        QWidget* widget3 = new QWidget();
        QVBoxLayout* layout3 = new QVBoxLayout(widget3);

        layout3->addWidget(btn3);
        layout3->setAlignment(Qt::AlignCenter);
        layout3->setContentsMargins(1, 1, 1, 1);
        widget3->setLayout(layout3);
        ui->sales_invoice->setCellWidget(i, 14, widget3);

        //button req
        QPushButton* btn4 = new QPushButton();
        QIcon icon4(":/img/res/btn/free-icon-edit-4007772.png");
        btn4->setIcon(icon4);
        btn4->setFixedWidth(25);
        btn4->setFixedHeight(25);

        int value4 = resArr[i][0].toInt();
        connect(btn4, &QPushButton::clicked, this, [this, value4]() {
            EditAccount editAccount(value4, 2);
            editAccount.setFixedHeight(248);
            connect(&editAccount, &EditAccount::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
            editAccount.exec();
        });

        QWidget* widget4 = new QWidget();
        QVBoxLayout* layout4 = new QVBoxLayout(widget4);

        layout4->addWidget(btn4);
        layout4->setAlignment(Qt::AlignCenter);
        layout4->setContentsMargins(1, 1, 1, 1);
        widget4->setLayout(layout4);
        ui->sales_invoice->setCellWidget(i, 15, widget4);
    }

    ui->sales_invoice->resizeColumnsToContents();

    for (int col = 0; col < ui->sales_invoice->columnCount(); ++col) {
        ui->sales_invoice->setColumnWidth(col, std::min(ui->sales_invoice->columnWidth(col), 200));
    }
}

void InfWindow::fillPayInstruction()
{
    //pay instruction--------------------------------------------------------

    db_control.query1(QString("SELECT a.id, c.company_name, c.edrpou, c.account, c.bank, a.supplier, a.edrpou, a.supplier_account, a.supplier_bank, a.total_sum, a.pi_acceptance_date, a.pi_execution_date, a.pi_visa FROM account as a, companies as c WHERE a.buyer = c.id and a.visa = 1 and a.account_id='%1' ORDER BY a.id DESC;").arg(id));
    QVector<QVector<QVariant>> resArr = db_control.results;

    ui->pay_instruction_table->setRowCount(resArr.size());
    ui->pay_instruction_table->setColumnCount(14);

    QStringList headers;
    headers << "№ рахунку"
            << "Платник"
            << "Код платника"
            << "Рахунок платника"
            << "Надавач платіжних послуг платника"
            << "Отримувач"
            << "Код отримувача"
            << "Рахунок отримувача"
            << "Надавач платіжних послуг отримувача"
            << "Сума"
            << "Дата прийняття до виконання"
            << "Дата виконання"
            << "Підпис платника"
            << "Редагувати";

    ui->pay_instruction_table->setHorizontalHeaderLabels(headers);

    for (int i = 0; i < ui->pay_instruction_table->rowCount(); ++i) {
        QTableWidgetItem* item = new QTableWidgetItem(resArr[i][0].toString());
        ui->pay_instruction_table->setItem(i, 0, item);

        item = new QTableWidgetItem(resArr[i][1].toString());
        ui->pay_instruction_table->setItem(i, 1, item);

        item = new QTableWidgetItem(resArr[i][2].toString());
        ui->pay_instruction_table->setItem(i, 2, item);

        item = new QTableWidgetItem(resArr[i][3].toString());
        ui->pay_instruction_table->setItem(i, 3, item);

        item = new QTableWidgetItem(resArr[i][4].toString());
        ui->pay_instruction_table->setItem(i, 4, item);

        item = new QTableWidgetItem(resArr[i][5].toString());
        ui->pay_instruction_table->setItem(i, 5, item);

        item = new QTableWidgetItem(resArr[i][6].toString());
        ui->pay_instruction_table->setItem(i, 6, item);

        item = new QTableWidgetItem(resArr[i][7].toString());
        ui->pay_instruction_table->setItem(i, 7, item);

        item = new QTableWidgetItem(resArr[i][8].toString());
        ui->pay_instruction_table->setItem(i, 8, item);

        item = new QTableWidgetItem(resArr[i][9].toString());
        ui->pay_instruction_table->setItem(i, 9, item);

        item = new QTableWidgetItem(resArr[i][10].toString());
        ui->pay_instruction_table->setItem(i, 10, item);

        item = new QTableWidgetItem(resArr[i][11].toString());
        ui->pay_instruction_table->setItem(i, 11, item);

        //check box
        QCheckBox* checkBox = new QCheckBox("");
        if (resArr[i][12].toInt() == 1) {
            checkBox->setChecked(true);
        } else {
            checkBox->setChecked(false);
        }

        connect(checkBox, &QCheckBox::stateChanged, [=](int state) {
            if (state == Qt::Checked) {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET pi_visa = '%1' WHERE id = '%2'").arg(1).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            } else {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET pi_visa = '%1' WHERE id = '%2'").arg(0).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            }
        });

        QWidget* widget = new QWidget();
        QVBoxLayout* layout = new QVBoxLayout(widget);
        layout->addWidget(checkBox);
        layout->setAlignment(Qt::AlignCenter);
        layout->setContentsMargins(1, 1, 1, 1);
        widget->setLayout(layout);

        ui->pay_instruction_table->setCellWidget(i, 12, widget);

        //button req
        QPushButton* btn4 = new QPushButton();
        QIcon icon4(":/img/res/btn/free-icon-edit-4007772.png");
        btn4->setIcon(icon4);
        btn4->setFixedWidth(25);
        btn4->setFixedHeight(25);

        int value4 = resArr[i][0].toInt();
        connect(btn4, &QPushButton::clicked, this, [this, value4]() {
            EditAccount editAccount(value4, 4);
            editAccount.setFixedHeight(248);
            connect(&editAccount, &EditAccount::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
            editAccount.exec();
        });

        QWidget* widget4 = new QWidget();
        QVBoxLayout* layout4 = new QVBoxLayout(widget4);

        layout4->addWidget(btn4);
        layout4->setAlignment(Qt::AlignCenter);
        layout4->setContentsMargins(1, 1, 1, 1);
        widget4->setLayout(layout4);
        ui->pay_instruction_table->setCellWidget(i, 13, widget4);
    }

    ui->pay_instruction_table->resizeColumnsToContents();

    for (int col = 0; col < ui->pay_instruction_table->columnCount(); ++col) {
        ui->pay_instruction_table->setColumnWidth(col, std::min(ui->pay_instruction_table->columnWidth(col), 250));
    }
}

void InfWindow::fillAttorneyPower()
{
    //Attorney Power
    db_control.query1(QString("SELECT a.id, a.v_date_get, a.v_date_to, a.v_issued_to, a.v_pasport_data, a.supplier, c.company_name, c.account, c.address, a.v_visa_of_issued, a.v_visa_director FROM account as a, companies as c WHERE a.buyer = c.id and a.visa = 1 and a.pi_visa = 1 and a.account_id='%1' ORDER BY a.id DESC;").arg(id));

    QVector<QVector<QVariant>> resArr = db_control.results;

    ui->attorney_power_table->setRowCount(resArr.size());
    ui->attorney_power_table->setColumnCount(13);

    QStringList headers;
    headers << "№ рахунку"
            << "Дата видачі"
            << "Дійсна до"
            << "Видано"
            << "Паспортні дані"
            << "На отримання від"
            << "Покупець"
            << "Рахунок покупця"
            << "Адреса покупця"
            << "Підпис особи, що одержала довіреність"
            << "Підпис керіника підприємства"
            << "Товари"
            << "Редагувати";

    ui->attorney_power_table->setHorizontalHeaderLabels(headers);

    for (int i = 0; i < ui->attorney_power_table->rowCount(); ++i) {
        QTableWidgetItem* item = new QTableWidgetItem(resArr[i][0].toString());
        ui->attorney_power_table->setItem(i, 0, item);

        item = new QTableWidgetItem(resArr[i][1].toString());
        ui->attorney_power_table->setItem(i, 1, item);

        item = new QTableWidgetItem(resArr[i][2].toString());
        ui->attorney_power_table->setItem(i, 2, item);

        item = new QTableWidgetItem(resArr[i][3].toString());
        ui->attorney_power_table->setItem(i, 3, item);

        item = new QTableWidgetItem(resArr[i][4].toString());
        ui->attorney_power_table->setItem(i, 4, item);

        item = new QTableWidgetItem(resArr[i][5].toString());
        ui->attorney_power_table->setItem(i, 5, item);

        item = new QTableWidgetItem(resArr[i][6].toString());
        ui->attorney_power_table->setItem(i, 6, item);

        item = new QTableWidgetItem(resArr[i][7].toString());
        ui->attorney_power_table->setItem(i, 7, item);

        item = new QTableWidgetItem(resArr[i][8].toString());
        ui->attorney_power_table->setItem(i, 8, item);

        //check box
        QCheckBox* checkBox = new QCheckBox("");
        if (resArr[i][9].toInt() == 1) {
            checkBox->setChecked(true);
        } else {
            checkBox->setChecked(false);
        }

        connect(checkBox, &QCheckBox::stateChanged, [=](int state) {
            if (state == Qt::Checked) {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET v_visa_of_issued = '%1' WHERE id = '%2'").arg(1).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            } else {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET v_visa_of_issued = '%1' WHERE id = '%2'").arg(0).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            }
        });

        QWidget* widget = new QWidget();
        QVBoxLayout* layout = new QVBoxLayout(widget);
        layout->addWidget(checkBox);
        layout->setAlignment(Qt::AlignCenter);
        layout->setContentsMargins(1, 1, 1, 1);
        widget->setLayout(layout);

        ui->attorney_power_table->setCellWidget(i, 9, widget);

        QCheckBox* checkBox2 = new QCheckBox("");
        if (resArr[i][10].toInt() == 1) {
            checkBox2->setChecked(true);
        } else {
            checkBox2->setChecked(false);
        }

        connect(checkBox2, &QCheckBox::stateChanged, [=](int state) {
            if (state == Qt::Checked) {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET v_visa_director= '%1' WHERE id = '%2'").arg(1).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            } else {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET v_visa_director = '%1' WHERE id = '%2'").arg(0).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            }
        });

        QWidget* widget2 = new QWidget();
        QVBoxLayout* layout2 = new QVBoxLayout(widget2);
        layout2->addWidget(checkBox2);
        layout2->setAlignment(Qt::AlignCenter);
        layout2->setContentsMargins(1, 1, 1, 1);
        widget2->setLayout(layout2);

        ui->attorney_power_table->setCellWidget(i, 10, widget2);
        //check box end

        //button open products
        QPushButton* btn3 = new QPushButton();
        QIcon icon3(":/img/res/btn/free-icon-expand-8975040.png");
        btn3->setIcon(icon3);
        btn3->setFixedWidth(25);
        btn3->setFixedHeight(25);

        int value3 = resArr[i][0].toInt();
        connect(btn3, &QPushButton::clicked, this, [this, value3]() {
            Products products(id, value3, 1);
            connect(&products, &Products::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
            products.exec();
        });

        QWidget* widget3 = new QWidget();
        QVBoxLayout* layout3 = new QVBoxLayout(widget3);

        layout3->addWidget(btn3);
        layout3->setAlignment(Qt::AlignCenter);
        layout3->setContentsMargins(1, 1, 1, 1);
        widget3->setLayout(layout3);
        ui->attorney_power_table->setCellWidget(i, 11, widget3);

        //button req
        QPushButton* btn4 = new QPushButton();
        QIcon icon4(":/img/res/btn/free-icon-edit-4007772.png");
        btn4->setIcon(icon4);
        btn4->setFixedWidth(25);
        btn4->setFixedHeight(25);

        int value4 = resArr[i][0].toInt();
        connect(btn4, &QPushButton::clicked, this, [this, value4]() {
            EditAccount editAccount(value4, 1);
            editAccount.setFixedHeight(248);
            connect(&editAccount, &EditAccount::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
            editAccount.exec();
        });

        QWidget* widget4 = new QWidget();
        QVBoxLayout* layout4 = new QVBoxLayout(widget4);

        layout4->addWidget(btn4);
        layout4->setAlignment(Qt::AlignCenter);
        layout4->setContentsMargins(1, 1, 1, 1);
        widget4->setLayout(layout4);
        ui->attorney_power_table->setCellWidget(i, 12, widget4);
    }

    ui->attorney_power_table->resizeColumnsToContents();

    for (int col = 0; col < ui->attorney_power_table->columnCount(); ++col) {
        ui->attorney_power_table->setColumnWidth(col, std::min(ui->attorney_power_table->columnWidth(col), 250));
    }
}

void InfWindow::fillProductNa()
{
    db_control.query1(QString("SELECT * FROM product_na WHERE user_id='%1' ORDER BY id DESC;").arg(id));

    QVector<QVector<QVariant>> resArr = db_control.results;
    ui->product_na_table->setRowCount(resArr.size());
    ui->product_na_table->setColumnCount(7);

    QStringList headers;
    headers << "№ накладної"
            << "Здав"
            << "Прийняв"
            << "Дата"
            << "Сума"
            << "Переглянути"
            << "Видалити";

    ui->product_na_table->setHorizontalHeaderLabels(headers);

    for (int i = 0; i < ui->product_na_table->rowCount(); ++i) {

        QTableWidgetItem* item = new QTableWidgetItem(resArr[i][0].toString());
        ui->product_na_table->setItem(i, 0, item);

        item = new QTableWidgetItem(resArr[i][1].toString());
        ui->product_na_table->setItem(i, 1, item);

        item = new QTableWidgetItem(resArr[i][2].toString());
        ui->product_na_table->setItem(i, 2, item);

        item = new QTableWidgetItem(resArr[i][3].toString());
        ui->product_na_table->setItem(i, 3, item);

        item = new QTableWidgetItem(resArr[i][4].toString());
        ui->product_na_table->setItem(i, 4, item);

        QPushButton* btn = new QPushButton();
        QIcon icon(":/img/res/btn/free-icon-expand-8975040.png");
        btn->setIcon(icon);
        btn->setFixedWidth(25);
        btn->setFixedHeight(25);

        int value = resArr[i][0].toInt();
        connect(btn, &QPushButton::clicked, this, [this, value]() {
            Products products(id, value, 2);
            connect(&products, &Products::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
            products.exec();
        });

        QWidget* widget2 = new QWidget();
        QVBoxLayout* layout2 = new QVBoxLayout(widget2);

        layout2->addWidget(btn);
        layout2->setAlignment(Qt::AlignCenter);
        layout2->setContentsMargins(1, 1, 1, 1);
        widget2->setLayout(layout2);
        ui->product_na_table->setCellWidget(i, 5, widget2);

        QPushButton* btn4 = new QPushButton();
        QIcon icon4(":/img/res/btn/free-icon-delete-1214428.png");
        btn4->setIcon(icon4);
        btn4->setFixedWidth(25);
        btn4->setFixedHeight(25);

        value = resArr[i][0].toInt();
        connect(btn4, &QPushButton::clicked, this, [this, value]() {
            QMessageBox msgBox;
            msgBox.setWindowTitle("Підтвердження");
            msgBox.setText("Видалити накладну?");

            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
            msgBox.button(QMessageBox::Yes)->setText("Так");
            msgBox.button(QMessageBox::No)->setText("Ні");

            if (msgBox.exec() == QMessageBox::Yes) {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q = QString("DELETE FROM product_na WHERE id = '%1' and user_id = '%2';").arg(value).arg(id);

                if (!q2.exec(str_q)) {
                    qDebug() << "Delete Error TO DB!";
                }
            }
        });

        QWidget* widget4 = new QWidget();
        QVBoxLayout* layout4 = new QVBoxLayout(widget4);

        layout4->addWidget(btn4);
        layout4->setAlignment(Qt::AlignCenter);
        layout4->setContentsMargins(1, 1, 1, 1);
        widget4->setLayout(layout4);
        ui->product_na_table->setCellWidget(i, 6, widget4);
    }

    ui->product_na_table->resizeColumnsToContents();

    for (int col = 0; col < ui->product_na_table->columnCount(); ++col) {
        ui->product_na_table->setColumnWidth(col, std::min(ui->product_na_table->columnWidth(col), 200));
    }
}

void InfWindow::fillTableWidget()
{

    db_control.query1(QString("SELECT a.id, a.published_by, c.company_name, c.tel, a.supplier, a.supplier_address, a.supplier_tel, a.edrpou, a.supplier_account, a.get_date, a.supplier_bank, a.visa FROM account as a, companies as c WHERE a.buyer = c.id and a.account_id='%1' ORDER BY a.id DESC;").arg(id));

    QVector<QVector<QVariant>> resArr = db_control.results;

    for (int i = 0; i < resArr.size(); ++i) {
        db_control.query1(QString("select amount, price from products where product_id='%1'").arg(resArr[i][0].toInt()));
        int sum = 0;

        for (int k = 0; k < db_control.results.size(); ++k) {
            int recount = db_control.results[k][0].toInt() * db_control.results[k][1].toInt();
            sum += recount;
        }

        resArr[i].push_back(sum);
    }

    ui->tableWidget->setRowCount(resArr.size());
    ui->tableWidget->setColumnCount(16);

    QStringList headers;
    headers << "Виписав(ла)"
            << "Покупець"
            << "Телефон покупця"
            << "Постачальник"
            << "Адреса постачальника"
            << "Телефон постачальника"
            << "ЄДРПОУ"
            << "Рахунок отримувача"
            << "Дата отримання"
            << "Надавач платіжних послуг"
            << "Загальна сума"
            << "Підпис покупця"
            << "Товари"
            << "№"
            << "Редагувати"
            << "Видалити";
    ui->tableWidget->setHorizontalHeaderLabels(headers);

    for (int i = 0; i < ui->tableWidget->rowCount(); ++i) {

        QTableWidgetItem* item = new QTableWidgetItem(resArr[i][1].toString());
        ui->tableWidget->setItem(i, 0, item);

        item = new QTableWidgetItem(resArr[i][2].toString());
        ui->tableWidget->setItem(i, 1, item);

        item = new QTableWidgetItem(resArr[i][3].toString());
        ui->tableWidget->setItem(i, 2, item);

        item = new QTableWidgetItem(resArr[i][4].toString());
        ui->tableWidget->setItem(i, 3, item);

        item = new QTableWidgetItem(resArr[i][5].toString());
        ui->tableWidget->setItem(i, 4, item);

        item = new QTableWidgetItem(resArr[i][6].toString());
        ui->tableWidget->setItem(i, 5, item);

        item = new QTableWidgetItem(resArr[i][7].toString());
        ui->tableWidget->setItem(i, 6, item);

        item = new QTableWidgetItem(resArr[i][8].toString());
        ui->tableWidget->setItem(i, 7, item);

        item = new QTableWidgetItem(resArr[i][9].toString());
        ui->tableWidget->setItem(i, 8, item);

        item = new QTableWidgetItem(resArr[i][10].toString());
        ui->tableWidget->setItem(i, 9, item);

        QSqlQuery q2 = QSqlQuery(db_control.db);
        QString str_q5 = QString("UPDATE account SET total_sum = '%1' WHERE id = '%2'").arg(resArr[i][12].toInt()).arg(resArr[i][0].toInt());

        if (!q2.exec(str_q5)) {
            qDebug() << "Update Error TO DB!";
        }

        item = new QTableWidgetItem(resArr[i][12].toString());
        ui->tableWidget->setItem(i, 10, item);

        QCheckBox* checkBox = new QCheckBox("");

        if (resArr[i][11].toInt() == 1) {
            checkBox->setChecked(true);
        } else {
            checkBox->setChecked(false);
        }

        connect(checkBox, &QCheckBox::stateChanged, [=](int state) {
            if (state == Qt::Checked) {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET visa = '%1' WHERE id = '%2'").arg(1).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            } else {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q2 = QString("UPDATE account SET visa = '%1' WHERE id = '%2'").arg(0).arg(resArr[i][0].toInt());

                if (!q2.exec(str_q2)) {
                    qDebug() << "Update Error TO DB!";
                }
            }
        });

        QWidget* widget = new QWidget();

        QVBoxLayout* layout = new QVBoxLayout(widget);

        layout->addWidget(checkBox);
        layout->setAlignment(Qt::AlignCenter);
        layout->setContentsMargins(1, 1, 1, 1);
        widget->setLayout(layout);

        ui->tableWidget->setCellWidget(i, 11, widget);

        QPushButton* btn = new QPushButton();
        QIcon icon(":/img/res/btn/free-icon-expand-8975040.png");
        btn->setIcon(icon);
        btn->setFixedWidth(25);
        btn->setFixedHeight(25);

        int value = resArr[i][0].toInt();
        connect(btn, &QPushButton::clicked, this, [this, value]() {
            onButtonClicked1(value);
        });

        QWidget* widget2 = new QWidget();
        QVBoxLayout* layout2 = new QVBoxLayout(widget2);

        layout2->addWidget(btn);
        layout2->setAlignment(Qt::AlignCenter);
        layout2->setContentsMargins(1, 1, 1, 1);
        widget2->setLayout(layout2);
        ui->tableWidget->setCellWidget(i, 12, widget2);

        item = new QTableWidgetItem(resArr[i][0].toString());
        ui->tableWidget->setItem(i, 13, item);

        QPushButton* btn3 = new QPushButton();
        QIcon icon3(":/img/res/btn/free-icon-edit-4007772.png");
        btn3->setIcon(icon3);
        btn3->setFixedWidth(25);
        btn3->setFixedHeight(25);

        value = resArr[i][0].toInt();
        connect(btn3, &QPushButton::clicked, this, [this, value]() {
            onButtonClicked2(value);
        });

        QWidget* widget3 = new QWidget();
        QVBoxLayout* layout3 = new QVBoxLayout(widget3);

        layout3->addWidget(btn3);
        layout3->setAlignment(Qt::AlignCenter);
        layout3->setContentsMargins(1, 1, 1, 1);
        widget3->setLayout(layout3);
        ui->tableWidget->setCellWidget(i, 14, widget3);

        QPushButton* btn4 = new QPushButton();
        QIcon icon4(":/img/res/btn/free-icon-delete-1214428.png");
        btn4->setIcon(icon4);
        btn4->setFixedWidth(25);
        btn4->setFixedHeight(25);

        value = resArr[i][0].toInt();
        connect(btn4, &QPushButton::clicked, this, [this, value]() {
            QMessageBox msgBox;
            msgBox.setWindowTitle("Підтвердження");
            msgBox.setText("Видалити рахунок?");

            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
            msgBox.button(QMessageBox::Yes)->setText("Так");
            msgBox.button(QMessageBox::No)->setText("Ні");

            if (msgBox.exec() == QMessageBox::Yes) {
                QSqlQuery q2 = QSqlQuery(db_control.db);
                QString str_q = QString("DELETE FROM account WHERE id = '%1';").arg(value);

                if (!q2.exec(str_q)) {
                    qDebug() << "Delete Error TO DB!";
                }
            }
        });

        QWidget* widget4 = new QWidget();
        QVBoxLayout* layout4 = new QVBoxLayout(widget4);

        layout4->addWidget(btn4);
        layout4->setAlignment(Qt::AlignCenter);
        layout4->setContentsMargins(1, 1, 1, 1);
        widget4->setLayout(layout4);
        ui->tableWidget->setCellWidget(i, 15, widget4);
    }

    ui->tableWidget->resizeColumnsToContents();

    for (int col = 0; col < ui->tableWidget->columnCount(); ++col) {
        ui->tableWidget->setColumnWidth(col, std::min(ui->tableWidget->columnWidth(col), 200));
    }
}

void InfWindow::on_pushButton_3_clicked()
{
    fillPayInstruction();
}

void InfWindow::onButtonClicked1(int val)
{
    Products products(id, val);
    connect(&products, &Products::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
    products.exec();
    qDebug() << val;
}

void InfWindow::onButtonClicked2(int val)
{
    EditAccount editAccount(val);
    editAccount.setFixedHeight(248);
    connect(&editAccount, &EditAccount::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
    editAccount.exec();
}

void InfWindow::on_add_clicked()
{
    AccountForm accountForm(id);
    accountForm.setFixedSize(671, 639);

    connect(&accountForm, &AccountForm::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
    accountForm.exec();
}

void InfWindow::on_update_clicked()
{
    fillTableWidget();
}

void InfWindow::on_action_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->page1);
}

void InfWindow::on_action_2_triggered()
{

    ui->stackedWidget->setCurrentWidget(ui->page2);
    fillPayInstruction();
}

void InfWindow::on_action_7_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->organization_edit);
    fillEditOrganization();
}

void InfWindow::activateDatabaseConnection()
{
    db_control = DBControl();
    qDebug() << "emit db conn";
}

void InfWindow::on_action_3_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->page3);
    fillAttorneyPower();
}

void InfWindow::on_action_4_triggered()
{

    ui->stackedWidget->setCurrentWidget(ui->organization);
}

void InfWindow::on_action_5_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->page4);
    fillSalesInvoice();
}

void InfWindow::on_action_6_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->page5);
    fillWarehouse();
}

void InfWindow::on_pushButton_2_clicked()
{
    ui->final_err->setText("");

    QString val1 = ui->lineEdit_1->text();
    QString val2 = ui->lineEdit_2->text();
    QString val3 = ui->lineEdit_3->text();
    QString val4 = ui->lineEdit_4->text();
    QString val5 = ui->lineEdit_5->text();
    QString val6 = ui->lineEdit_6->text();

    qDebug() << val1;

    bool flag = true;

    if (val1 != "") {
        ui->err1->setText("");
    } else {
        ui->err1->setText("Пусте поле");
        flag = false;
    }

    if (val2 != "") {
        ui->err2->setText("");
    } else {
        ui->err2->setText("Пусте поле");
        flag = false;
    }

    if (val3 != "") {
        ui->err3->setText("");
    } else {
        ui->err3->setText("Пусте поле");
        flag = false;
    }

    if (val4 != "") {
        ui->err4->setText("");
    } else {
        ui->err4->setText("Пусте поле");
        flag = false;
    }

    if (val5 != "") {
        ui->err5->setText("");
    } else {
        ui->err5->setText("Пусте поле");
        flag = false;
    }

    if (val6 != "") {
        ui->err6->setText("");
    } else {
        ui->err6->setText("Пусте поле");
        flag = false;
    }

    if (flag) {
        QSqlQuery q2 = QSqlQuery(db_control.db);
        QString str_q2 = QString("INSERT INTO companies (company_name, address, tel, edrpou, bank, account, user_id) values('%1', '%2', '%3', '%4', '%5', '%6', '%7')").arg(val1).arg(val2).arg(val3).arg(val4).arg(val5).arg(val6).arg(id);

        if (!q2.exec(str_q2)) {
            qDebug() << "Insert Error TO DB:" << q2.lastError().text();
        } else {
            ui->final_err->setText("Організація створена");
        }
    }
}

void InfWindow::on_pushButton_clicked()
{
    fillAttorneyPower();
}

void InfWindow::on_pushButton_4_clicked()
{
    fillSalesInvoice();
}

void InfWindow::on_pushButton_5_clicked()
{
    fillWarehouse();
}

void InfWindow::on_pushButton_9_clicked()
{
    fillEditOrganization();
}

void InfWindow::fillEditOrganization()
{
    edit_organization_model = new QSqlTableModel(this, db_control.db);
    edit_organization_model->setTable("companies");
    edit_organization_model->select();

    QString filter = QString("user_id = %1").arg(id);
    edit_organization_model->setFilter(filter);

    edit_organization_model->setHeaderData(1, Qt::Horizontal, "Назва організації", Qt::DisplayRole);
    edit_organization_model->setHeaderData(2, Qt::Horizontal, "Адреса", Qt::DisplayRole);
    edit_organization_model->setHeaderData(3, Qt::Horizontal, "Телефон", Qt::DisplayRole);
    edit_organization_model->setHeaderData(4, Qt::Horizontal, "ЄДРПОУ", Qt::DisplayRole);
    edit_organization_model->setHeaderData(5, Qt::Horizontal, "Рахунок", Qt::DisplayRole);
    edit_organization_model->setHeaderData(6, Qt::Horizontal, "Надавач платіжних послуг", Qt::DisplayRole);

    ui->organization_edit_table->setModel(edit_organization_model);

    ui->organization_edit_table->setColumnHidden(0, true);
    ui->organization_edit_table->setColumnHidden(7, true);

    ui->organization_edit_table->resizeColumnsToContents();

    for (int col = 0; col < edit_organization_model->columnCount(); ++col) {
        ui->organization_edit_table->setColumnWidth(col, std::min(ui->organization_edit_table->columnWidth(col), 200));
    }
}

void InfWindow::on_pushButton_7_clicked()
{

    int selectedRow = ui->organization_edit_table->currentIndex().row();

    if (selectedRow >= 0) {
        qDebug() << "rem row" << edit_organization_model->removeRow(selectedRow);
        qDebug() << "Error removing row:" << edit_organization_model->lastError().text();
    } else {
        qDebug() << "no selected row";
    }

    qDebug() << selectedRow << "!!!!";
}

void InfWindow::on_action_8_triggered()
{
    ProdutctNa product_na(id);
    product_na.setFixedSize(644, 641);
    connect(&product_na, &ProdutctNa::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);

    product_na.exec();
}

void InfWindow::on_action_9_triggered()
{
    ui->stackedWidget->setCurrentWidget(ui->product_na);
}

void InfWindow::on_pushButton_10_clicked()
{
    fillProductNa();
}

void InfWindow::on_action_10_triggered()
{
    AccountForm accountForm(id);
    accountForm.setFixedSize(671, 639);

    connect(&accountForm, &AccountForm::returnedToMainWindow, this, &InfWindow::activateDatabaseConnection);
    accountForm.exec();
}
