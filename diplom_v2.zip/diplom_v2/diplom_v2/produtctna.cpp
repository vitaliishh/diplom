#include "produtctna.h"
#include "ui_produtctna.h"

ProdutctNa::ProdutctNa(int user_id, QWidget* parent)
    : QDialog(parent)
    , ui(new Ui::ProdutctNa)
{
    ui->setupUi(this);

    ui->dateEdit->setDate(QDate::currentDate());
    this->user_id = user_id;

    ui->product_na_table->setRowCount(1);
    ui->product_na_table->setColumnCount(2);

    QStringList headers;
    headers << "Номер товару"
            << "Кількість";

    ui->product_na_table->setHorizontalHeaderLabels(headers);

    QHeaderView* header = ui->product_na_table->horizontalHeader();

    header->setSectionResizeMode(QHeaderView::Interactive);
    header->setMinimumSectionSize(100);

    ui->product_na_table->resizeColumnsToContents();
    //    ui->product_na_table->setColumnWidth(3, 200);
}

ProdutctNa::~ProdutctNa()
{
    qDebug() << "dell product na";
    emit returnedToMainWindow();
    delete ui;
}

void ProdutctNa::on_pushButton_clicked()
{
    ui->send_err->setText("");

    bool flag = true;

    for (int i = 0; i < ui->product_na_table->rowCount(); ++i) {

        QString prod_num = "";

        if (ui->product_na_table->item(i, 0) != nullptr) {
            prod_num = ui->product_na_table->item(i, 0)->text();
        }

        QString amount = "";

        if (ui->product_na_table->item(i, 1) != nullptr) {
            amount = ui->product_na_table->item(i, 1)->text();
        }

        if (prod_num != "") {

            bool var_type;
            int var = prod_num.toInt(&var_type);
            if (var) {
                ui->final_err->setText("");

            } else {
                ui->final_err->setText(QString("Введіть число в комірці [%1, %2]").arg(i + 1).arg(1));
                flag = false;
                break;
            }

        } else {
            ui->final_err->setText(QString("Комірка [%1, %2] пусте значення").arg(i + 1).arg(1));
            flag = false;
            break;
        }

        if (amount != "") {

            bool var_type;
            int var = amount.toInt(&var_type);
            if (var) {
                ui->final_err->setText("");

            } else {
                ui->final_err->setText(QString("Введіть число в комірці [%1, %2]").arg(i + 1).arg(2));
                flag = false;
                break;
            }

        } else {
            ui->final_err->setText(QString("Комірка [%1, %2] пусте значення").arg(i + 1).arg(2));
            flag = false;
            break;
        }
    }

    QString from_edit = ui->from_edit->text();
    QString to_edit = ui->to_edit->text();
    QString date_edit = ui->dateEdit->text();

    if (from_edit != "") {
        ui->err1->setText("");
    } else {
        ui->err1->setText("Пусте поле");
        flag = false;
    }
    if (to_edit != "") {
        ui->err2->setText("");
    } else {
        ui->err2->setText("Пусте поле");
        flag = false;
    }

    if (flag) {

        bool flag2 = true;

        //перевірка на існування номера товару
        for (int i = 0; i < ui->product_na_table->rowCount(); ++i) {

            db_control.query1(QString("SELECT id FROM products WHERE account_id = '%1' and id = '%2';").arg(user_id).arg(ui->product_na_table->item(i, 0)->text()));

            if (db_control.results.size() == 0) {

                ui->send_err->setText(QString("Відсутній товар з номером %1").arg(ui->product_na_table->item(i, 0)->text()));
                flag2 = false;
                break;
            } else {
                ui->send_err->setText("");
            }
        }

        bool flag3 = true;

        //перевірка чи кількість не перевищує існуючу
        if (flag2) {

            for (int i = 0; i < ui->product_na_table->rowCount(); ++i) {

                db_control.query1(QString("SELECT edit_amount FROM products WHERE account_id = '%1' and id = '%2';").arg(user_id).arg(ui->product_na_table->item(i, 0)->text()));

                if (ui->product_na_table->item(i, 1)->text().toInt() <= db_control.results[0][0].toInt()) {
                    ui->send_err->setText("");
                } else {
                    ui->send_err->setText(QString("Перевищений ліміт кількості товару з номером %1").arg(ui->product_na_table->item(i, 0)->text()));
                    flag3 = false;
                    break;
                }
            }
        }

        //створення накладної без товарів
        if (flag2 && flag3) {
            //шукаємо суму всіх товарів
            int total_sum = 0;

            for (int i = 0; i < ui->product_na_table->rowCount(); ++i) {

                db_control.query1(QString("SELECT price, edit_amount FROM products WHERE account_id = '%1' and id = '%2';").arg(user_id).arg(ui->product_na_table->item(i, 0)->text()));

                int price = db_control.results[0][0].toInt();
                int amount = db_control.results[0][1].toInt();

                int count_up = price * ui->product_na_table->item(i, 1)->text().toInt();
                total_sum += count_up;
            }

            //створюємо саму накладну
            bool flag5 = true;

            QSqlQuery q2 = QSqlQuery(db_control.db);
            QString str_q2 = QString("INSERT INTO product_na (from_, to_, date, total_sum, user_id) values('%1', '%2', '%3', '%4', '%5');").arg(from_edit).arg(to_edit).arg(date_edit).arg(total_sum).arg(user_id);

            if (!q2.exec(str_q2)) {
                qDebug() << "Insert Error TO DB:" << q2.lastError().text();
                flag = false;
            } else {
            }

            //створюємо items накладної

            if (flag5) {
                db_control.query1(QString("SELECT id FROM product_na WHERE from_ = '%1' and to_ = '%2' and date = '%3' and total_sum = '%4' and user_id = '%5' ORDER BY id DESC;").arg(from_edit).arg(to_edit).arg(date_edit).arg(total_sum).arg(user_id));

                int id_last_product_na = db_control.results[0][0].toInt();

                for (int i = 0; i < ui->product_na_table->rowCount(); ++i) {

                    db_control.query1(QString("SELECT product_name, price, edit_amount FROM products WHERE account_id = '%1' and id = '%2';").arg(user_id).arg(ui->product_na_table->item(i, 0)->text()));

                    QString name = db_control.results[0][0].toString();
                    int price = db_control.results[0][1].toInt();
                    int amount = db_control.results[0][2].toInt();
                    qDebug() << name << price;

                    QSqlQuery q3 = QSqlQuery(db_control.db);
                    QString str_q3 = QString("INSERT INTO product_na_items (id_na, user_id, name, amount, price, total_sum) values('%1', '%2', '%3', '%4', '%5', '%6');").arg(id_last_product_na).arg(user_id).arg(name).arg(ui->product_na_table->item(i, 1)->text()).arg(price).arg(ui->product_na_table->item(i, 1)->text().toInt() * price);

                    if (!q3.exec(str_q3)) {
                        qDebug() << "Insert Error TO DB:" << q3.lastError().text();
                    } else {
                    }

                    int difference = amount - ui->product_na_table->item(i, 1)->text().toInt();

                    QSqlQuery q4 = QSqlQuery(db_control.db);
                    QString str_q4 = QString("UPDATE products SET edit_amount = '%1' WHERE account_id = '%2' and id = '%3';").arg(difference).arg(user_id).arg(ui->product_na_table->item(i, 0)->text());

                    if (!q4.exec(str_q4)) {
                        qDebug() << "Update Error TO DB!";

                    } else {
                        ui->send_err->setStyleSheet("color: green;");
                        ui->send_err->setText("Накладну спішно створено");
                        ui->pushButton->setEnabled(false);
                    }
                }
            }
        }
    }
}

void ProdutctNa::on_pushButton_2_clicked()
{
    int row = ui->product_na_table->rowCount();
    ui->product_na_table->insertRow(row);
}

void ProdutctNa::on_pushButton_3_clicked()
{
    QModelIndexList selectedRows = ui->product_na_table->selectionModel()->selectedRows();

    if (selectedRows.isEmpty()) {
        QMessageBox msgBox;
        msgBox.setText("Для видалення виберіть рядок");
        msgBox.setWindowTitle("Попередження");
        msgBox.addButton("Добре", QMessageBox::AcceptRole);
        msgBox.exec();
    } else {
        foreach (QModelIndex index, selectedRows) {
            qDebug() << index.row();

            if (index.row() != 0) {
                ui->product_na_table->removeRow(index.row());
            } else {

                QMessageBox msgBox;
                msgBox.setText("Видалення рядка 1 заборонено");
                msgBox.setWindowTitle("Попередження");
                msgBox.addButton("Добре", QMessageBox::AcceptRole);
                msgBox.exec();
            }
        }
    }
}
