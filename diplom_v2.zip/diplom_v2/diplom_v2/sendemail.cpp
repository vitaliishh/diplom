
#include "sendemail.h"

SendEmail::SendEmail()
{
}

QString SendEmail::sendEmail1(int code, QString sendTo)
{
    MimeMessage message;

    EmailAddress sender(MY_ACCOUNT, "Реєстрація");
    message.setSender(sender);

    EmailAddress to(sendTo, "Користувач");
    message.addRecipient(to);

    message.setSubject("Реєстрація акаунту");

    // Now add some text to the email.
    // First we create a MimeText object.

    MimeHtml* text = new MimeHtml();

    QString textMess = QString("<h2>Код для реєстрації:\n %1</h2>").arg(code);
    text->setText(textMess);

    //Now add it to the mail
    message.addPart(text);

    // Now we can send the mail
    SmtpClient smtp("smtp.gmail.com", 465, SmtpClient::SslConnection);

    smtp.connectToHost();
    if (!smtp.waitForReadyConnected()) {
        qDebug() << "Failed to connect to host!";
    }

    smtp.login(MY_ACCOUNT, MY_PASS);
    if (!smtp.waitForAuthenticated()) {
        qDebug() << "Failed to login!";
    }

    smtp.sendMail(message);
    if (!smtp.waitForMailSent()) {
        qDebug() << "Failed to send mail!";
        smtp.quit();
        return "Код не відправлено";
    } else {
        qDebug() << "Email sent - OK";
        qDebug() << "Reg code:" << code;
        smtp.quit();
        return "Код відправлено";
    }

    smtp.quit();
    return "Виникла помилка";
}
