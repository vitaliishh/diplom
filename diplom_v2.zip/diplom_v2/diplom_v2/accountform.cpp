#include "accountform.h"
#include "ui_accountform.h"

AccountForm::AccountForm(int id, QWidget* parent)
    : QDialog(parent)
    , ui(new Ui::AccountForm)
{
    ui->setupUi(this);
    this->id = id;

    QSqlQuery q2 = QSqlQuery(db_control.db);
    if (!q2.exec(QString("SELECT company_name FROM companies WHERE user_id='%1'").arg(id))) {
        qDebug() << db_control.db.lastError().databaseText();
        qDebug() << db_control.db.lastError().driverText();
    }
    while (q2.next()) {
        ui->comboBox->addItem(q2.value(0).toString());
    }
}

AccountForm::~AccountForm()
{
    qDebug() << "dell acc form";
    emit returnedToMainWindow();
    delete ui;
}

void AccountForm::on_pushButton_clicked()
{

    qDebug() << id;

    QString val1 = ui->comboBox->currentText();
    QString val3 = ui->lineEdit_3->text();
    QString val4 = ui->lineEdit_4->text();
    QString val5 = ui->lineEdit_5->text();
    QString val6 = ui->lineEdit_6->text();
    QString val7 = ui->dateEdit->text();
    QString val8 = ui->lineEdit_7->text();

    QString val9 = ui->lineEdit_8->text();
    QString val10 = ui->lineEdit_9->text();

    bool flag = true;

    if (val3 != "") {
        ui->err2->setText("");
    } else {
        ui->err2->setText("Пусте значення");
        flag = false;
    }

    if (val6 != "") {
        ui->err3->setText("");
    } else {
        ui->err3->setText("Пусте значення");
        flag = false;
    }

    if (val10 != "") {
        ui->err4->setText("");
    } else {
        ui->err4->setText("Пусте значення");
        flag = false;
    }

    if (flag) {
        QSqlQuery q2 = QSqlQuery(db_control.db);

        if (!q2.exec(QString("SELECT id FROM companies WHERE company_name = '%1' AND user_id = '%2'").arg(val1).arg(id))) {
            qDebug() << db_control.db.lastError().databaseText();
            qDebug() << db_control.db.lastError().driverText();
        }

        int val1_new;

        while (q2.next()) {
            val1_new = q2.value(0).toInt();
        }

        QSqlQuery q3 = QSqlQuery(db_control.db);
        QString str_q3 = QString("INSERT INTO account (account_id, buyer, buyer_tel, pi_buyer_address,  pi_buyer_edrpou, pi_buyer_account, pi_buyer_bank, supplier, supplier_tel, edrpou, supplier_account, get_date, supplier_bank, supplier_address, published_by) values('%1', '%2', '%3', '%4', '%5', '%6', '%7', '%8', '%9', '%10', '%11', '%12', '%13', '%14', '%15')").arg(id).arg(val1_new).arg(val1_new).arg(val1_new).arg(val1_new).arg(val1_new).arg(val1_new).arg(val3).arg(val4).arg(val5).arg(val6).arg(val7).arg(val8).arg(val9).arg(val10);

        if (!q3.exec(str_q3)) {
            qDebug() << "Insert Error TO DB:" << q3.lastError().text();
        } else {
            ui->final_err->setText("Рахунок додано");
        }
    }
}

void AccountForm::on_pushButton_2_clicked()
{
    close();
}
