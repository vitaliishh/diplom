#ifndef INFWINDOW_H
#define INFWINDOW_H

#include "accountform.h"
#include "dbcontrol.h"
#include "editaccount.h"
#include "products.h"
#include "produtctna.h"
#include <QCheckBox>
#include <QMainWindow>
#include <QMessageBox>
#include <QPushButton>
#include <QSqlQuery>
#include <QSqlRelationalDelegate>
#include <QSqlRelationalTableModel>
#include <QSqlTableModel>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVector>
#include <algorithm>

namespace Ui {
class InfWindow;
}

class InfWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit InfWindow(int id, QString nick, QString email, QString pass, QWidget* parent = nullptr);
    ~InfWindow();

private:
    Ui::InfWindow* ui;
    int id;
    QString nick;
    QString email;
    QString pass;
    DBControl db_control;

    void fillTableWidget();
    void fillPayInstruction();
    void fillAttorneyPower();
    void fillSalesInvoice();
    void fillWarehouse(int mode = 0);
    void fillEditOrganization();
    void fillProductNa();

    QSqlRelationalTableModel* payment_instruction_model;
    QSqlRelationalTableModel* attorney_power_model;
    QSqlTableModel* edit_organization_model;

public slots:
    void activateDatabaseConnection();
private slots:
    void onButtonClicked1(int val);
    void onButtonClicked2(int val);
    void on_add_clicked();
    void on_update_clicked();
    void on_action_triggered();
    void on_action_2_triggered();
    void on_action_3_triggered();
    void on_action_4_triggered();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_clicked();
    void on_action_5_triggered();
    void on_pushButton_4_clicked();
    void on_action_6_triggered();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_8_clicked();
    void on_action_7_triggered();
    void on_pushButton_9_clicked();
    void on_pushButton_7_clicked();
    void on_action_8_triggered();
    void on_action_9_triggered();
    void on_pushButton_10_clicked();
    void on_action_10_triggered();
};

#endif // INFWINDOW_H
