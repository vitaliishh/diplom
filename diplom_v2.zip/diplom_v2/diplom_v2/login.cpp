
#include "login.h"
#include "ui_login.h"

Login::Login(QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);

    //    QString pass = "12345";
    //    QString pass_hash = QCryptographicHash::hash(pass.toUtf8(), QCryptographicHash::Md5);
    //    //    qDebug() << pass_hash;
    //    //    ui->label->setText(pass_hash);

    //    db.query1("select * from accounts");

    //    db.printRes();
    //    qDebug() << db.results[3][2];

    //    bool j = pass_hash == db.results[3][2];
    //    qDebug() << j;
}

Login::~Login()
{
    qDebug() << "dell Login Win";
    delete ui;
}

void Login::on_pushButton_3_clicked()
{
    db_control.db.close();
    QSqlDatabase::removeDatabase("my_connection");
    Registration reg;
    reg.exec();
}

void Login::on_pushButton_4_clicked()
{
    db_control.db.close();
    QSqlDatabase::removeDatabase("my_connection");
    RestorePass restore_pass;
    restore_pass.exec();
}

void Login::on_pushButton_clicked()
{
    QString nick = ui->nick->text();
    QString pass = ui->pass->text();
    ui->sign_in_err->setText("");

    bool flag = true;

    if (nick != "") {
        ui->nick_err->setText("");
    } else {
        ui->nick_err->setText("Пусте поле");
        flag = false;
    }

    if (pass != "") {
        ui->pass_err->setText("");
    } else {
        ui->pass_err->setText("Пусте поле");
        flag = false;
    }

    if (flag) {
        QString pass_hash = QCryptographicHash::hash(pass.toUtf8(), QCryptographicHash::Md5);

        db_control = DBControl();
        db_control.query1(QString("select * from accounts where name='%1' and pass='%2'").arg(nick).arg(pass_hash));
        db_control.printRes();

        if (db_control.results.size() == 0) {
            ui->sign_in_err->setText("Не правильний нік чи пароль");
        } else {

            db_control.db.close();
            QSqlDatabase::removeDatabase("my_connection");

            InfWindow* infW = new InfWindow(db_control.results[0][0].toInt(), db_control.results[0][1].toString(), db_control.results[0][3].toString(), db_control.results[0][2].toString());
            infW->setAttribute(Qt::WA_DeleteOnClose);
            infW->show();

            close();
        }
    }
}
